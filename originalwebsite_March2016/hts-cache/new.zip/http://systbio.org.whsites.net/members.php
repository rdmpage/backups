<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
 <title>Society of Systematic Biologists | Home of Systematic Biology</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<base href="http://systbio.org/" />
<style type="text/css" media="all">@import "misc/drupal.css";</style><link rel="alternate" type="application/rss+xml" title="RSS" href="http://systbio.org/?q=node/feed" />
 <link rel="stylesheet" type="text/css" href="themes/chameleon/common.css" />
<style type="text/css" media="all">@import "themes/chameleon/style.css";</style></head><body>
 <div id="header">  <a href="./" title="Home"><img src="files/chameleon_logo.jpg" alt="Home" /></a></div>

 <div class="navlinks"><div class="primary"><a href="?q=" title="Return to the main page.">home</a> | <a href="?q=aggregator" title="Read the latest news from syndicated web sites.">news feeds</a></div> </div>
<BR><BR>
<h4>The Society's membership directory is now searchable.  Use the suggested search tips below to maximize the effectiveness of your search.</h4>
		<p><b>Search Tips:</b> <ul>
		<li>Search for last name only initially.
		<li>There is a limit of 15 returns per query, so choose search terms carefully.
		<li>For common names, such as &quot;Jones&quot; or &quot;Smith,&quot; or names with spaces, such as  &quot;de Queiroz,&quot;  include the first name of the person in the appropriate box.
		<li>Do not put quotes or other punctuation marks in or around your search string.
		<li>The search finds parts of names, so  &quot;Smith&quot; will find  &quot;Smith,&quot; but also &quot;Smithsonian&quot;</p>
		<li>Enter your query to search the SSB membership directory:
		
		</ul>
		<FORM METHOD=POST ACTION="results.php">

Last Name: <INPUT TYPE="text" NAME="lastname" SIZE="35"><BR>
First Name: <INPUT TYPE="text" NAME="firstname" SIZE="35"><BR>






<PRE><INPUT TYPE="submit" VALUE="Search"></PRE>

</FORM>

		
		
		
		