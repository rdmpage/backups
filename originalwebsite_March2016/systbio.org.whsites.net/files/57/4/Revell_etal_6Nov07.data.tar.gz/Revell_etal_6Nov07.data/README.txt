Guide to data files:

Data folders are labelled according to the scenarios in the text of the manuscript.

Data for each scenario consists of five folders, each containing the results for a different set of simulation conditions.

Folder names are fairly self-explanatory.  Each folder contains raw data from the numerical simulation (.means file), values for K for each simulation (.k file), and the trees (trees).

Please feel free to contact Liam Revell (lrevell@fas.harvard.edu) with any questions or if further data or source code files are desired.

- Liam Revell, Dave Collar, Luke Harmon
