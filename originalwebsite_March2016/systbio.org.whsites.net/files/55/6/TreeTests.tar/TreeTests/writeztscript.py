#Ashleigh Smythe
#This script writes a series of bash commands to run zt on all SymD files
#(comparing them to the matrix of parameter distances).
#Python script to run zt is runzt.py - use writeztscript.py to generate
#appropriate number of zt calls. Modify the output command line according
#to how SymD files were named.
########
#Start the program at the python prompt with writeztscript.write()
########

def write():
    i=1
    while i < 1001:
        line = ("cmd = './zt -se 10culledmptreesexclchars%s.sdist.txt parameterdistances.txt >>exclcharszt.out'") % i
        print line
        line2 = "handle=os.popen(cmd, 'r')"
        print line2
        line3='handle.close()'
        print line3
        i=i+1
        
        
        
