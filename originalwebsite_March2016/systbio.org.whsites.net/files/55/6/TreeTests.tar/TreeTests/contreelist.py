#Ashleigh Smythe
#12-8-03
This script is designed to generate a series of commands for a
#paup script to calculate the consensus indices for each tree in a tree
#file, one by one.  It generates lines like:
#contree 1 /indices=yes showtree=no;
#contree 2 /indices=yes showtree=no;
#Just add the following to the top of the file to make a
#complete paup execution script:
#   #NEXUS
#   begin paup;
#   log file=openxextxindices.log;
#   execute openxextx.nex (with paup block commented out)
#   gettrees file=allopenxextxbspool.out (file that has all my trees)
####
#Start the program at the python prompt with contreelist.makelist()
#The main function makelist takes no arguments so just change i < to
#one greater than the number of contree command lines you'd like.
####
#One can parse the output file to extract the normalized consensus fork index
#(and take the average and standard deviation) with my script normconforkstats.py.

def makelist():
    i=1
    while i < 5:
        linepart1 = "%s" % ('contree')
        linepart2 = "%s" % ('/indices=yes showtree=no;')
        print linepart1, i, linepart2
        i=i+1

        
