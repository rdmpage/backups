#Ashleigh Smythe
#This script is written by writeztscript.py and is a series of zt commands.

import os
cmd = './zt -se 10BStreesexclchars1.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars2.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars3.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars4.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars5.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars6.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars7.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars8.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars9.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars10.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars11.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars12.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars13.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars14.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars15.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars16.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars17.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars18.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars19.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars20.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars21.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars22.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars23.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars24.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars25.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars26.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars27.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars28.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars29.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars30.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars31.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars32.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars33.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars34.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars35.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars36.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars37.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars38.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars39.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars40.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars41.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars42.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars43.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars44.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars45.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars46.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars47.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars48.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars49.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars50.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars51.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars52.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars53.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars54.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars55.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars56.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars57.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars58.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars59.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars60.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars61.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars62.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars63.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars64.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars65.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars66.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars67.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars68.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars69.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars70.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars71.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars72.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars73.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars74.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars75.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars76.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars77.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars78.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars79.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars80.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars81.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars82.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars83.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars84.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars85.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars86.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars87.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars88.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars89.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars90.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars91.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars92.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars93.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars94.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars95.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars96.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars97.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars98.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars99.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars100.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars101.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars102.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars103.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars104.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars105.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars106.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars107.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars108.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars109.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars110.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars111.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars112.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars113.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars114.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars115.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars116.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars117.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars118.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars119.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars120.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars121.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars122.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars123.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars124.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars125.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars126.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars127.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars128.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars129.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars130.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars131.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars132.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars133.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars134.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars135.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars136.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars137.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars138.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars139.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars140.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars141.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars142.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars143.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars144.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars145.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars146.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars147.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars148.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars149.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars150.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars151.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars152.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars153.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars154.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars155.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars156.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars157.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars158.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars159.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars160.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars161.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars162.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars163.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars164.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars165.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars166.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars167.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars168.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars169.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars170.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars171.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars172.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars173.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars174.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars175.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars176.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars177.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars178.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars179.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars180.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars181.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars182.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars183.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars184.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars185.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars186.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars187.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars188.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars189.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars190.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars191.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars192.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars193.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars194.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars195.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars196.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars197.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars198.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars199.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars200.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars201.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars202.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars203.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars204.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars205.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars206.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars207.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars208.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars209.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars210.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars211.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars212.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars213.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars214.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars215.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars216.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars217.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars218.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars219.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars220.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars221.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars222.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars223.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars224.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars225.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars226.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars227.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars228.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars229.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars230.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars231.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars232.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars233.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars234.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars235.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars236.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars237.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars238.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars239.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars240.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars241.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars242.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars243.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars244.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars245.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars246.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars247.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars248.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars249.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars250.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars251.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars252.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars253.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars254.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars255.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars256.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars257.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars258.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars259.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars260.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars261.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars262.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars263.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars264.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars265.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars266.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars267.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars268.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars269.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars270.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars271.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars272.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars273.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars274.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars275.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars276.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars277.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars278.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars279.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars280.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars281.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars282.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars283.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars284.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars285.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars286.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars287.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars288.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars289.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars290.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars291.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars292.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars293.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars294.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars295.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars296.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars297.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars298.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars299.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars300.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars301.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars302.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars303.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars304.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars305.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars306.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars307.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars308.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars309.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars310.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars311.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars312.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars313.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars314.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars315.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars316.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars317.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars318.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars319.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars320.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars321.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars322.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars323.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars324.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars325.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars326.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars327.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars328.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars329.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars330.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars331.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars332.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars333.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars334.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars335.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars336.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars337.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars338.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars339.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars340.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars341.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars342.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars343.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars344.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars345.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars346.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars347.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars348.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars349.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars350.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars351.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars352.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars353.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars354.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars355.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars356.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars357.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars358.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars359.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars360.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars361.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars362.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars363.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars364.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars365.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars366.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars367.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars368.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars369.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars370.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars371.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars372.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars373.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars374.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars375.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars376.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars377.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars378.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars379.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars380.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars381.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars382.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars383.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars384.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars385.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars386.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars387.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars388.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars389.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars390.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars391.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars392.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars393.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars394.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars395.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars396.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars397.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars398.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars399.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars400.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars401.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars402.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars403.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars404.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars405.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars406.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars407.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars408.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars409.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars410.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars411.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars412.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars413.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars414.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars415.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars416.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars417.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars418.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars419.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars420.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars421.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars422.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars423.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars424.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars425.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars426.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars427.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars428.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars429.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars430.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars431.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars432.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars433.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars434.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars435.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars436.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars437.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars438.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars439.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars440.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars441.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars442.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars443.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars444.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars445.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars446.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars447.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars448.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars449.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars450.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars451.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars452.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars453.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars454.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars455.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars456.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars457.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars458.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars459.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars460.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars461.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars462.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars463.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars464.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars465.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars466.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars467.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars468.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars469.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars470.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars471.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars472.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars473.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars474.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars475.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars476.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars477.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars478.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars479.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars480.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars481.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars482.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars483.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars484.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars485.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars486.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars487.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars488.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars489.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars490.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars491.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars492.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars493.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars494.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars495.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars496.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars497.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars498.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars499.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars500.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars501.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars502.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars503.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars504.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars505.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars506.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars507.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars508.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars509.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars510.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars511.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars512.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars513.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars514.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars515.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars516.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars517.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars518.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars519.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars520.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars521.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars522.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars523.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars524.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars525.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars526.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars527.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars528.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars529.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars530.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars531.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars532.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars533.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars534.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars535.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars536.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars537.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars538.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars539.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars540.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars541.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars542.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars543.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars544.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars545.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars546.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars547.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars548.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars549.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars550.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars551.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars552.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars553.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars554.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars555.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars556.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars557.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars558.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars559.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars560.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars561.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars562.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars563.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars564.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars565.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars566.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars567.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars568.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars569.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars570.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars571.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars572.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars573.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars574.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars575.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars576.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars577.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars578.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars579.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars580.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars581.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars582.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars583.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars584.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars585.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars586.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars587.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars588.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars589.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars590.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars591.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars592.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars593.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars594.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars595.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars596.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars597.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars598.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars599.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars600.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars601.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars602.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars603.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars604.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars605.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars606.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars607.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars608.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars609.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars610.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars611.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars612.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars613.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars614.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars615.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars616.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars617.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars618.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars619.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars620.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars621.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars622.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars623.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars624.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars625.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars626.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars627.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars628.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars629.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars630.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars631.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars632.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars633.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars634.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars635.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars636.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars637.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars638.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars639.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars640.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars641.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars642.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars643.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars644.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars645.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars646.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars647.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars648.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars649.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars650.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars651.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars652.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars653.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars654.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars655.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars656.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars657.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars658.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars659.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars660.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars661.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars662.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars663.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars664.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars665.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars666.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars667.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars668.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars669.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars670.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars671.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars672.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars673.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars674.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars675.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars676.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars677.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars678.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars679.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars680.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars681.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars682.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars683.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars684.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars685.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars686.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars687.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars688.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars689.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars690.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars691.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars692.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars693.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars694.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars695.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars696.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars697.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars698.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars699.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars700.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars701.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars702.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars703.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars704.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars705.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars706.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars707.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars708.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars709.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars710.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars711.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars712.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars713.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars714.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars715.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars716.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars717.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars718.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars719.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars720.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars721.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars722.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars723.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars724.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars725.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars726.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars727.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars728.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars729.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars730.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars731.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars732.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars733.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars734.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars735.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars736.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars737.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars738.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars739.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars740.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars741.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars742.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars743.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars744.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars745.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars746.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars747.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars748.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars749.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars750.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars751.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars752.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars753.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars754.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars755.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars756.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars757.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars758.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars759.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars760.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars761.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars762.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars763.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars764.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars765.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars766.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars767.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars768.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars769.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars770.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars771.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars772.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars773.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars774.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars775.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars776.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars777.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars778.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars779.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars780.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars781.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars782.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars783.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars784.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars785.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars786.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars787.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars788.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars789.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars790.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars791.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars792.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars793.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars794.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars795.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars796.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars797.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars798.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars799.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars800.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars801.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars802.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars803.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars804.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars805.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars806.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars807.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars808.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars809.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars810.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars811.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars812.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars813.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars814.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars815.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars816.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars817.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars818.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars819.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars820.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars821.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars822.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars823.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars824.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars825.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars826.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars827.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars828.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars829.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars830.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars831.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars832.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars833.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars834.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars835.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars836.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars837.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars838.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars839.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars840.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars841.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars842.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars843.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars844.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars845.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars846.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars847.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars848.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars849.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars850.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars851.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars852.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars853.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars854.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars855.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars856.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars857.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars858.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars859.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars860.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars861.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars862.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars863.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars864.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars865.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars866.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars867.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars868.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars869.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars870.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars871.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars872.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars873.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars874.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars875.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars876.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars877.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars878.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars879.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars880.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars881.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars882.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars883.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars884.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars885.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars886.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars887.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars888.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars889.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars890.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars891.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars892.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars893.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars894.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars895.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars896.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars897.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars898.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars899.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars900.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars901.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars902.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars903.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars904.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars905.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars906.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars907.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars908.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars909.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars910.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars911.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars912.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars913.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars914.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars915.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars916.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars917.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars918.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars919.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars920.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars921.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars922.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars923.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars924.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars925.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars926.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars927.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars928.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars929.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars930.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars931.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars932.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars933.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars934.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars935.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars936.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars937.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars938.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars939.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars940.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars941.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars942.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars943.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars944.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars945.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars946.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars947.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars948.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars949.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars950.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars951.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars952.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars953.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars954.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars955.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars956.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars957.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars958.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars959.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars960.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars961.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars962.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars963.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars964.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars965.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars966.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars967.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars968.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars969.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars970.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars971.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars972.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars973.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars974.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars975.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars976.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars977.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars978.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars979.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars980.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars981.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars982.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars983.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars984.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars985.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars986.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars987.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars988.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars989.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars990.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars991.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars992.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars993.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars994.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars995.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars996.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars997.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars998.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars999.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
cmd = './zt -se 10BStreesexclchars1000.sdist.txt parameterdistances.txt >>BSexclcharszt.out'
handle=os.popen(cmd, 'r')
handle.close()
