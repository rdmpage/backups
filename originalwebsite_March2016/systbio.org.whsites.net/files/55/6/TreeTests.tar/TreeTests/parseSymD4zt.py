#Ashleigh Smythe
#This script parses the output files of paupAmongAlignsSymD.py.
#It is designed to take the output of paup's symmetric difference
#and strip away all the stuff that zt (for doing Mantel's test) doesn't like:
#the top tree line, the first line of 1     0, the number labels for each line
#and the diagonal zeros. It adds a "10" at the top, as zt wants to know the
#size of the matrix. It saves the edited matrix to a new file with the old
#file name plus .txt.
#######
##Can either do a single file by calling parseSD4zt.search('file_to_search')
##or can have script make a series of input files with .parse().
#######

import re
import string
import os

def search(file_to_search):
    infile=open(file_to_search, 'r')
    newfile='%s.%s' % (file_to_search, 'txt')
    outfile=open(newfile, 'w')
    mainlist=[]                                          
    for line in infile:                                 
        if re.search('^1\t0', line):         
            firstline='10\n'            
            mainlist.append(firstline)
        if re.search('^2\t', line):
            secondline=line[1:-2]+'\n'
            bettersecondline=string.lstrip(secondline)          
            mainlist.append(bettersecondline)
        if re.search('^3\t', line):
            thirdline=line[1:-2]+'\n'
            betterthirdline=string.lstrip(thirdline)
            mainlist.append(betterthirdline)
        if re.search('^4\t', line):
            fourthline=line[1:-2]+'\n'
            betterfourthline=string.lstrip(fourthline)
            mainlist.append(betterfourthline)
        if re.search('^5\t', line):
            fifthline=line[1:-2]+'\n'
            betterfifthline=string.lstrip(fifthline)
            mainlist.append(betterfifthline)
        if re.search('^6\t', line):
            sixthline=line[1:-2]+'\n'
            bettersixthline=string.lstrip(sixthline)
            mainlist.append(bettersixthline)
        if re.search('^7\t', line):
            seventhline=line[1:-2]+'\n'
            betterseventhline=string.lstrip(seventhline)
            mainlist.append(betterseventhline)            
        if re.search('^8\t', line):
            eighthline=line[1:-2]+'\n'
            bettereighthline=string.lstrip(eighthline)
            mainlist.append(bettereighthline)
        if re.search('^9\t', line):
            ninthline=line[1:-2]+'\n'
            betterninthline=string.lstrip(ninthline)
            mainlist.append(betterninthline)
        if re.search('^10\t', line):
            tenthline=line[2:-2]+'\n'
            bettertenthline=string.lstrip(tenthline)
            mainlist.append(bettertenthline) 
            mainstring=string.join(mainlist, '')
            outfile.write(mainstring)
        
def parse():
    i=1
    while i < 1001:
        line = ('10culledmptreesexclchars%s.sdist') % i
        asearch=search(line)
        i=i+1
        

            

   
