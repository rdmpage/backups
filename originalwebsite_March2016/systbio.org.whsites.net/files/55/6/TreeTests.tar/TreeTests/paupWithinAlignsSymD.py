#Ashleigh Smythe
##11-13-04 This script writes a series of paup commands to get a tree from the full and a tree from the culled
##for the same alignment parameters and get the SymD.  This writes a script for paup
##to do that or a full tree and then another full tree from the same alignment parameter.
######
#This script gets manually changed for each comparison within alignments-
#the number of trees in each file is listed (i.e. 598 in one file, 816 in the other one)
#so I just change the letter of the random number generator and the names of the
#files each time and work my way down the list.
######
#Start the program at the python prompt with paupWithinAlignsSymD.writelines()
######

import random

def writelines():
    z=1
    while z < 1001:
        a=random.randint(1,598)#choose a random number between 1 and the number of trees in that file
        a2=random.randint(1,816)
        b=random.randint(1,441)
        b2=random.randint(1,422)
        c=random.randint(1,174)
        c2=random.randint(1,648)
        d=random.randint(1,201)
        d2=random.randint(1,156)
        e=random.randint(1,3066)
        e2=random.randint(1,320)
        f=random.randint(1,1827)
        f2=random.randint(1,1)
        g=random.randint(1,2297)
        g2=random.randint(1,3265)
        h=random.randint(1,3959)
        h2=random.randint(1,1248)
        i=random.randint(1,2119)
        i2=random.randint(1,553)
        j=random.randint(1,1433)
        j2=random.randint(1,2093)                  
        line = ('gettrees file=open60ext10allchars.tre from=%s to=%s mode=3;') % (j, j)
        print line
        line = ('gettrees file=open60ext10culledonlyMP.tre from=%s to=%s mode=7;') % (j2, j2)
        print line
        line2 = ('treedist file=open60ext10fullVculledonly.sdist fd=no append=yes;')
        print line2
        z=z+1
