#Ashleigh Smythe
#
#12-8-03  This is designed to parse the output of paup's consensus indices.
#I have another script (contreelist.py) that gets
#paup to compute consensus trees for individual
#trees and writes all the consensus indices to file.
#This script parses that file to pull out the normalized consensus fork
#indices into a python list of integers, and then calculates
#and returns the average (and standard deviation) consensus fork
#index for all trees in the file.
#####
#Start the program at the Python prompt with normconforkstats.normconforkstats('file_to_search')
#####


from __future__ import division
import re
import string                                          
import Numeric
import Scientific
from Scientific import Statistics

def mean(a):
    return float(Numeric.sum(a))/len(a)

def std_dev(a):
    return sqrt(mean((a-mean(a))**2))

def search(file_to_search):                               #searches the input file for
    infile=open(file_to_search, 'r')                      #line containing cons.fork, converts
    mainlist=[]                                           #it to an integer, and puts
    for line in infile:                                   #it into a list.
        if re.search('Component', line):         
            normconfork=float(line[63:68])             
            mainlist.append(normconfork)              
    return mainlist                              

def normconforkstats(file_to_search):                      #this executes the whole thing
    list_of_numbers=search(file_to_search)                 #so start the program with              
    the_mean=Scientific.Statistics.mean(list_of_numbers)   #normconforkstats.normconforkstats('file_to_search')
    the_std_dev=Scientific.Statistics.standardDeviation(list_of_numbers)
    return the_mean, the_std_dev
    
    
   



    


