##Ashleigh Smythe
#Written 10-28-04 to parse the output of a nexus file (with commands scripted by paupAmongAlignsSymD.py)
#which is a series of SymD matrices.  It finds the mean and standard deviations of SymD values in a file.
#The file test.sdist is included as an example of a file of SymD matrices.
#########
#Start program at the python prompt with parseSD.parse()
#########

import string
import Scientific
from Scientific import Statistics

    
def flatten(L):
    if not isinstance(L,list): return [L]
    if L == []: return L
    return flatten(L[0]) + flatten(L[1:])

        
def parse():
    myfile=open('test2.sdist')
    biglist=[] ##make a list for later sorting and finding low, high (range)
    for line in myfile:
        str(line)
        elements=line.split()
        if elements[0]=='2':
            elements1=elements[1]
        if elements[0] =='3':
            elements2=elements[1:3]
        if elements[0] == '4':
            elements3=elements[1:4]
        if elements[0] == '5':
            elements4=elements[1:5]
        if elements[0] == '6':
            elements5=elements[1:6]
        if elements[0] == '7':
            elements6=elements[1:7]
        if elements[0] == '8':
            elements7=elements[1:8]
        if elements[0] == '9':
            elements8=elements[1:9]
        if elements[0] == '10':
            elements9=elements[1:10]
            alist=[elements1,elements2,elements3,elements4,elements5,elements6,elements7,elements8,elements9]
            aflatlist=flatten(alist)
            aflatintlist=map(int,aflatlist)
            aflatintlist.sort()
            biglist.append(aflatintlist[0])
            biglist.append(aflatintlist[-1])
            the_mean=Scientific.Statistics.mean(aflatintlist)
            the_std_dev=Scientific.Statistics.standardDeviation(aflatintlist)
            print the_mean,",", the_std_dev
    biglist.sort()
    print "the low is:", biglist[0]
    print "the high is:", biglist[-1]
        

            
            


    
    

   

       
   


  
