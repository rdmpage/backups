#Ashleigh Smythe
#This script is designed to parse the output of zt (Mantel's test)
#if it is all in one file. The script runzt.py runs a series of mantel's
#tests and appends the results to a single file.  This script pulls
#out the r and p values from each run of zt and gives the mean and standard
#deviation of those values.
#A sample output file of zt results called testzt.out is included
#for testing.
########
#Start the program at the python prompt with parsezt.ztstats('file to search')
########

import re
import string
import Scientific
from Scientific import Statistics

def search_for_r(myfile):
    myfile=open(myfile, 'r')
    rvaluelist=[]
    for line in myfile:
        if re.search('^r', line):
            rvalue=float(line[6:14])
            rvaluelist.append(rvalue)
    return rvaluelist

def search_for_p(myfile):
    myfile=open(myfile, 'r')
    pvaluelist=[]
    for line in myfile:
        if re.search('^p', line):
            pvalue=float(line[6:14])
            pvaluelist.append(pvalue)
    return pvaluelist

def ztstats(file_to_search):
    the_rvalues=search_for_r(file_to_search)
    the_pvalues=search_for_p(file_to_search)
    mean_r=Scientific.Statistics.mean(the_rvalues)
    std_dev_r=Scientific.Statistics.standardDeviation(the_rvalues)
    mean_p=Scientific.Statistics.mean(the_pvalues)
    std_dev_p=Scientific.Statistics.standardDeviation(the_pvalues)
    print "The mean r value is:"
    print mean_r
    print "The standard deviation of the r values is:"
    print std_dev_r
    print "The mean p value is:"
    print mean_p
    print "The standard deviation of the p values is:"
    print std_dev_p
    
    
