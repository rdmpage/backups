#Ashleigh Smythe
#Written to generate a paup block of commands to get a random tree from each alignment
#file. Then get symmetric difference distance (SymD) among those 10 trees.  
#This puts each SymD matrix into a separate file so it can go into zt (after being cleaned
#up by parseSymD4zt.py).
#Combine these files into 1 big file with the cat command at the bash prompt to get one file to
#determine the grand mean and mean standard deviation of all matrices with parseSymD.py
#####
#Start the program at the python prompt with paupAmongAlignsSymD.writelines()
###

import random

def writelines():
    z=1
    while z < 1001:
        a=random.randint(1,473)#choose a random number between 1 and the number of trees in that file
        b=random.randint(1,191)
        c=random.randint(1,249)
        d=random.randint(1,63)
        e=random.randint(1,107)
        f=random.randint(1,179)
        g=random.randint(1,10000)
        h=random.randint(1,10000)
        i=random.randint(1,10000)
        j=random.randint(1,10000)
        
        line = ('gettrees file=open4ext2culledonlyMP.tre from=%s to=%s mode=3;') % (a, a)
        print line
        line = ('gettrees file=open6ext2culledonlyMP.tre from=%s to=%s mode=7;') % (b, b)
        print line
        line = ('gettrees file=open8ext2culledonlyMP.tre from=%s to=%s mode=7;') % (c, c)
        print line
        line = ('gettrees file=open10ext2culledonlyMP.tre from=%s to=%s mode=7;') % (d, d)
        print line
        line = ('gettrees file=open12ext2culledonlyMP.tre from=%s to=%s mode=7;') % (e, e)
        print line
        line = ('gettrees file=open20ext10culledonlyMP.tre from=%s to=%s mode=7;') % (f, f)
        print line
        line = ('gettrees file=open30ext10culledonlyMP.tre from=%s to=%s mode=7;') % (g, g)
        print line
        line = ('gettrees file=open40ext10culledonlyMP.tre from=%s to=%s mode=7;') % (h, h)
        print line
        line = ('gettrees file=open50ext10culledonlyMP.tre from=%s to=%s mode=7;') % (i, i)
        print line
        line = ('gettrees file=open60ext10culledonlyMP.tre from=%s to=%s mode=7;') % (j, j)
        print line
        line2 = ('treedist file=10culledonlyMPtrees%s.sd fd=no append=yes;') % z
        print line2
        z=z+1
        
