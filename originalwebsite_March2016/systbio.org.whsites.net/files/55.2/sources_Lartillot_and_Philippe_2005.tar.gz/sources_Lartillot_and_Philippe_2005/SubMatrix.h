

class SubMatrix		{

	public:

			SubMatrix();
			~SubMatrix();

	void		Copy(SubMatrix* from);
	void		CopyStationaries(double* from);

	int 		ComputeArray(int normalise = 1);
	int 		Diagonalise();

	void		ComputeExponential(double range, double** expo);
	double**	GetGenerator()	{return Q;}

	double& 	Stationary(int i);
	double& 	RelativeRate(int i, int j);

	double* GetStationaries()	{ return mStationary;}

	double 	EigenValue(int i) { return v[i];}

	void	PlugRelativeRates(double* inrelrate);
	void 	PlugStationaries(double* instat);

	double*	GetRelRatePtr() { return mRelativeRate;}

	// access to matrix Q colums and rows
	// inline double& operator()(int i, int j);			//
	// inline double& operator()(int i, int j) const ;
	double& operator()(int i, int j);			//
	double& operator()(int i, int j) const ;


	void	CheckDiag();

	//-------------
	// data fields
	//-------------

	double* mArray;

	// matrices as lists of rows
	// Q : the infinitesimal generator matrix
	// a : the copy of it -> to feed linalg ( as a list of rows)
	// v : eigenvalues
	// vi : imaginary part
	// u : the matrix of eigen vectors
	// invu : the inverse of u
	// wi : work vector
	// w : work vector
	//
	// total : 4 Nstate*Nstate + 4 * Nstate

	double ** Q;
	double ** a;
	double ** u;
	double ** invu;
	double * v;
	double * vi;

	double* mStationary;
	double*	mRelativeRate;		// mRelativeRates[i][j] = p(going to i given that we are on j)
								// this is symmetrix anyway
	int RelRatePushed;
	int StatPushed;
};
