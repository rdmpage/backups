#include <math.h>

#ifdef ALPHA
#define SAFE_EXP(x) ((x)<-200.0 ? 0.0 : exp(x))
#else
#define SAFE_EXP(x) (exp(x))
#endif



typedef long longer[6];

const double Log2 = log(2.0);

double approx(double f);

double factlog(int i);

const double Epsilon = 1e-15;


inline double log2(double d)	{
	return log(d) / Log2;
}


inline int sgn(double m)	{
	return (m>0 ?  1 : -1);
}

const double DBL_EPSILON = 1e-10;		// ??? what's that ?


class Random {
 public:
 
  	Random(int seed);

	static double Uniform();
//	static double randum(longer seed);
	/*
  	static double Beta(double alpha, double beta) {

	double x = Gamma(alpha,1);
    double y = Gamma(beta,1);
    return x/(x+y);
  	}
	*/

  	static double logGamma(double a);

	static double Gamma(double alpha,double beta);

	static unsigned long congrval;
  	static unsigned long tausval;
  	static unsigned long lambda;

  	static double sNormal(void);
  	static double sExpo(void);
  	static double sGamma(double);

 	static int Choose(int);

  	static void DrawFromUrn(int*, int, int);

	static longer sseed;
  };

