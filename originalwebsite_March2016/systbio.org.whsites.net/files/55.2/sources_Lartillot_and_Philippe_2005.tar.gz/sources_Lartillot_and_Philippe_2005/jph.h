#undef NO_ERROR
#undef ERROR
#define NO_ERROR	0
#define ERROR		1

#undef FALSE
#undef TRUE
#define FALSE		0
#define TRUE		1

#define NO			0
#define YES			1

#define UP			0
#define DOWN		1

#define	ORDERED		0
#define	UNORDERED	1

#define	pos(i,j,n)				((i)*(n)+(j))
