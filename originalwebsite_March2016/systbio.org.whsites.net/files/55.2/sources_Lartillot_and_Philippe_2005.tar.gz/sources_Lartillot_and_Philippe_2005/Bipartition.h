class TaxaParameters;

class Bipartition	{

	public:

	Bipartition(TaxaParameters* inParam);
	// empty by default

	Bipartition(const Bipartition& from);

	~Bipartition();

	Bipartition& 			operator=(const Bipartition& from);
	Bipartition& 			operator=(const string& from);

	Boolean				operator==( const Bipartition& inPartition); // no modulo !
	Boolean				operator!=( const Bipartition& inPartition); // no modulo !

	Bipartition&			operator|=( const Bipartition& inPartition); // assumes they are oriented likewise
	Bipartition&			operator&=( const Bipartition& inPartition);
	Bipartition			operator!();

	Boolean 			IsCompatibleWith( const Bipartition& inPartition);
	Boolean 			IsCompatibleWith( const Bipartition& inPartition, Boolean& Orientation);
	Boolean				IsInformative();

	int				GetTaxonStatus(Int16 index) ;
	void				SetTaxon(Int16 index);

	TaxaParameters*			GetParameters()	const;

	double				GetLength()	{return mLength;}
	void				SetLength(double inLength)	{mLength = inLength;}

	void				ToString(ostream& os);
	void				Modulo();
	// operator			string();

	int*				mArray;
			// -1 : species eliminated
			// 0 : species upstream
			// 1	: species downstream

	TaxaParameters* 		mParam;

	double				mLength;

	
}
;

