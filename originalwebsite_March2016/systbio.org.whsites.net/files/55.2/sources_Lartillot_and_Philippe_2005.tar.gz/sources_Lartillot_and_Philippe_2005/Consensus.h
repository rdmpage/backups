class PolyNode;
class BipartitionList;
class BooleanBipartitionList;
class Bipartition;
class TreeList;

class Consensus		:   public Tree	{

	public:

	Consensus(TreeList* 	inTreeList, int from = 0, int every = 1, double* probarray = 0);

	~Consensus();

	void						MakeConsensus(int from, int every, double* probarray);

	BipartitionList*				GetBList()		const   {return mBList;}

	TreeList*					GetTreeList()	const {return mTreeList;}
	void						Insert( Bipartition& inPartition, double prob, double length);

	TreeList*					mTreeList;

	BipartitionList*				mBList;
	BooleanBipartitionList*				mBBList;

}
;
