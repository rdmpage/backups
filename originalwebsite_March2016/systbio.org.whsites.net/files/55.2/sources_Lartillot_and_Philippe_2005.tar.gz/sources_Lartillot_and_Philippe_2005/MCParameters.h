
class PhyloBayes;
class Tree;

class MCParameters {

	public:

				MCParameters();
				~MCParameters();


	PhyloBayes*		GetCurrentState()	{return currentState[0];}
	PhyloBayes*		GetNextState()		{return nextState[0];}

	PhyloBayes*		GetCurrentState(int i)	{return currentState[i];}
	PhyloBayes*		GetNextState(int i)		{return nextState[i];}

	void			SetCurrentState(int i, PhyloBayes* inPB)	{ currentState[i] = inPB;}
	void			SetNextState(int i, PhyloBayes* inPB)	{ nextState[i] = inPB;}

	void			SetInitTree(Tree& tree);

	void			CreateJackStructures();

	void			Reset();				// called before the first start
	void			Regenerate();				// called before the first start
	void			Update(); 				// called before any start
	void			ResetUpdateFlags(int chain);

	void			InitFromFile(string filename);
	void			ReadMoveType(istream& is);
	void			ReadSuperMoveType(istream& is);
	void			ReadTopoMoveType(istream& is);
	void			ReadJacknife(string jackfilename);
	void			ReadDataFromFile(string datafilename);
	void			ReadNexus();
	void			ReadPhylip();
	void			WriteDataToFile(string datafilename, int N1, int N2);
	void			WriteDataToFile(string datafilename, int * Mask);
	void			AddConstantColumns(int N, double* freq, string datafilename);
	void			RegisterWithData();
	void			RegisterWithJackData();
	void			GetSequenceProfile(ostream& os, double pseudocount);
	int			ConstantColumns();

	void			Move();
	void			Move(int chain);
	void			TopoMove(int chain, int topo);
	void			SuperMove(int chain, int topo, int super);
	void			Move(int chain, int topo, int super, int move);
	void			Swap(int i);

	void			ResampleStat(int chain);
	void			ResampleState(int chain);
	void			ResampleSub(int chain);
	void			UpdateFastLogSampling(int chain);
	void			UpdatePruningLogSamp(int chain);

	// streams
	// ocstream : binary, compact streams
	// otstream : text streams

	friend otstream& operator<<( otstream& os , MCParameters& param);
	friend itstream& operator>>( itstream& is , MCParameters& param);

	friend ocstream& operator<<( ocstream& os , MCParameters& param);
	friend icstream& operator>>( icstream& is , MCParameters& param);


	int			Version;
	int			SubVersion;

	// -----------------------------
	// Model Parameters
	// ------------------------

	// data matrix

	string			DataFileSpec;				// nexus file containing the aligned sequences

	int 			Ntaxa;
	int 			Nnode;
	int 			Nsite;
	string*			SpeciesNames;
	int**	 		Data;						// Data[i][j] : taxon i, site j
	double*			EmpiricalFreq;

	Switch			DeleteConstant;
	Switch			Normalise;					// 1 : self-substitutions excluded while measuring lengths
										// 0 : self-substitutions included
	Switch			SavePartialLogLikelihoods;
	Switch			ModeFastCompute;
	Switch			RefFastCompute;
	Prior			LengthPrior;					// 0 : flat
	double			LengthMin;
	double			LengthMax;

	Prior			RatePrior;					// 0 : flat (only possible value as for now)
	double 			RateMin;
	double			RateMax;
	double			GammaMin;
	double			GammaMax;
	double			DeltaMin;
	double			DeltaMax;
	double			XiMin;
	double			XiMax;

	Prior			ModeStatPrior;					// idem
	Prior			RefStatPrior;
	double			StatMin;
	double			StatMax;
	double			StatAlphaMin;
	double			StatAlphaMax;

	double			AlphaMin;
	double			AlphaMax;
	double			BetaMin;
	double			BetaMax;

	// beware!
	// 	AlphaPrior : in fact; Gamma Prior
	Prior			AlphaPrior;	
	// 	RateAlphaPrior : in fact MeanLengthPrior
	Prior			RateAlphaPrior;					// 0 : flat
	double			RateAlphaMin;
	double			RateAlphaMax;
	double			RateBetaMin;
	double			RateBetaMax;

	double			TooSmall;
	double			TooLarge;
	double			InfProb;

	// ----------------------
	// chain parameters
	// ----------------------

	// Moves

	int 			TopoMoveTypeNumber;
	int**			TopoNIterationArray;
	int**			TopoNArray;
	TopoMoveType*		TopoMoveTypeArray;

	int* 			SuperMoveTypeNumber;
	int***			SuperNIterationArray;
										//  	Global, Local, Rates, SwitchMode...
	int** 			MoveTypeNumber;
	MoveType***		MoveTypeArray;					// type of nth. move (MoveType can take one of the values :
										//  	Global, Local, Rates, SwitchMode...
	int****			NIterationArray;				// mean number of calls to nth. move per cycle

	double****		deltaArray;					// real tuning parameter for the nth. move
										// 		(the meaning of this parameter is MoveType dependent)
	int****			NArray;						// integer tuning parameter for the nth. move
										//		(idem)
	// Saves and Stops
	int 			SaveEvery;					// Number of calls defining one chain's cycle
										// after each cycle, the chain saves its current state
										// and appends this state to the sample
	int			StopAfter;					// the chain will stop after having recorded
										// StopAfter points (burn in included)
										// if StopAfter == -1 	: the chain never stops
	int			HowManySaved;
	double			SwapFreq;

	// thermodynamic integration :

	ModelSwitchMode		MSMode;

	int			BurnIn;

	double			RASModelSwitch;
	double			SUBModelSwitch;
	double			HeteroModelSwitch;
	double			TreeModelSwitch;
	
	double			InitBeta;
	double			FinalBeta;
	double			BetaStep;
	int			BurnInDone;

	double*			Beta;
	double*			Zeta;
	double			Beta0;
	double			Zeta0;
	int			Nchain;
	MCMCMCType		MCMCMC;


	// Monte Carlo statistics

	// the following counters keep track of

	int			RateInfCount;					// # times maxrate/minrate exceeded authorised upper limit
	int			StatInfCount;					// # times maxstat/minstat exceeded authorised upper limit
	int			LengthInfCount;					// # times max branch length overflowed
	int			LogProbInfCount;				// # times a probability was found too small for its log to be computed
	int 			SwitchModeStatOutOfRangeCount;	// # same as StatInfCount, but specific for switch mode move

	int****			NCallArray;
	double****		TimeArray;
	double****		SuccessArray;

	int*			TrialSwapArray;
	int*			AcceptedSwapArray;

	PhyloBayes**		currentState;					// the current point in hypothesis space
	PhyloBayes**		nextState;						// its back up copy

	int*			StatUpdateFlag;
	int*			StateUpdateFlag;
	int*			SubUpdateFlag;
	int*			FastLogSamplingUpdateFlag;
	int*			PruningLogSampUpdateFlag;


	// ----------------------------------------
	// accesssory parameters
	// used for compaction of the state representation (in the case of catfish)
	// ------------------------------------------------

	Boolean**		Orbit;
	int*			OrbitSize;
	int*			ZipSize;
	int**			Indices;
	int**			ZipData;
	int*			ConstantState;

	int			DataOK;
	double 			SpeedFactor;

	int***			jackData;
	int***			jackZipData;
	double*			jackProportion;
	string			jackDataFile;

	int*			SwapPermut;

	MultiplicativeResampling Resampling;

	int			Parallel;
	int			SwapMode;
	int			StorePartialLikelihoods;
	int			SaveAllChains;

	HeterotachyMode		HeteroMode;
	HeterogeneityMode	BranchSwitchMode;
	HeterogeneityMode	OnOffMode;
	HeterogeneityMode	CovRateMode;

	Prior			BranchRatePrior;
	Prior			RateVarPrior;

	double* 		RateMixtureWeight;
	double* 		RateMixtureAlpha;
	double* 		RateMixtureBeta;
	int			RateMixtureComponentNumber;

	string			Path;
	void			SetPath(string inPath){Path = inPath;}
	string			GetPath(string inPath){return Path;}

	int**			SiteEmpiricalCount;
}
;
