
class PhyloBayes;
class Bipartition;
class BooleanBipartitionList;
class TaxaParameters;
class PolyNode;
class TreeList;

class PolyTree	{

	public:

	PolyTree();
	~PolyTree();


	TaxaParameters*				GetParameters()	const {return mParam;}
	void						SetParameters(const TaxaParameters* inParam)	{ mParam = inParam;}

	PolyNode*					GetRoot()	 {return mRoot;}
	PolyNode*					GetLeaf(Int16 inLabel);

	PolyNode*					FindNode(const Bipartition& inPartition, Boolean& Orientation);
	PolyNode*					FindNode(const Bipartition& inPartition)	{
										Boolean temp;
										return FindNode(inPartition, temp);
									}

	void						Erase()	{ mRoot = nil;}

							operator Boolean()	const { return (Boolean) mRoot;}

	PhyloBayes*					GetTemplate();
	void						MakeNewTemplate();
	void						Format();
	
	void						RootAt(PolyNode* inNode);			// uses PolyNode::FlipFLop
									// by definition, inNode->up == root
									//				  root->down = inNode
	void						RootAtWithPB(PolyNode* inNode);

	void						Eliminate(Bipartition toEliminate);
	void						FlushFields();
	
	void						BipartitionPruning(BooleanBipartitionList* inList);
		
	void						Draw(Rect inFrame, Boolean BL, Boolean withProb, Boolean withField);

	void						ToString(LStream& os);
	
	PolyNode*					OverABranch(Point inPt);

	protected:

	TaxaParameters*				mParam;	
	
	double						mLogProb;

	PolyNode*					mRoot;
	
	PolyNode*					mTree;
	
	PhyloBayes*					mTemplate;
}
;
