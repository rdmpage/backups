class PhyloBayes;
class PolyNode;

class Tree	{

	public	:


				Tree();
				Tree(string filename);
				Tree(istream& is);
				Tree(ifstream& is);
				Tree(PhyloBayes* inPB);

				Tree(Tree* from);
				
				~Tree();

	void			Clone(PolyNode* node, PolyNode* fromNode);

	PolyNode*		GetRoot()	{return mRoot;}

	PolyNode*		GetLeaf(Int16 inLabel);

	PolyNode*		FindNode(Bipartition& inPartition, Boolean& Orientation);
	PolyNode*		FindNode(Bipartition& inPartition);

	void			SetSuper();


	void			SetFormalBranchLengths(double scale);

	TaxaParameters*		GetParameters()	{return mParam;}
	void			SetParameters(TaxaParameters* inParam)	{ mParam = inParam;}

	void			SetLabelOffset(int offset);
	void			TranslateLabels(int offset);

	// void			RootAt(PolyNode* inNode);			// uses PolyNode::FlipFLop
									// by definition, inNode->up == root
									//				  root->down = inNode
	// void			Eliminate(Bipartition toEliminate);
	void			Eliminate(int SpeciesIndex);
	void			Eliminate(PolyNode* node, int SpeciesIndex);
	int			Eliminate(PolyNode* node, string SpeciesName);
	void			Eliminate(string SpeciesName);

	void			BipartitionPruning(BooleanBipartitionList* inList);

	void			Phylip(ostream& os, int withLengths = 1, int withProbs = 0, int withSpeciesNames = 0, int withInternalLabels = 0 );
	void			ToMrBayes(ostream& os);
	void			ToLatex(ostream& os, double sizeX, double sizeY, int withLengths=1, int withProbs = 0, int withSpeciesNames = 0, int withInternalLabels = 0);

	void			ReadFromStream(istream& is);
	void			ReadPhylip(istream& is, PolyNode* currentNode);
	int			RegisterWithData(string* SpeciesNames, int Ntaxa);

	int 			Dichotomise();
	void 			Trichotomise();
	int			IsDichotomous();


	Boolean			operator==(Tree& from);
	Boolean			operator!=(Tree& from);

	int			GetSize();
	void			GetSpeciesNames(string* name);
	void			SetSpeciesNames(string* name);

	int			WithBranchLengths;
	int			WithProb;
	int			WithSpeciesNames;

	TaxaParameters*		mParam;

	PolyNode*		mNodeList;
	PolyNode*		mRoot;

	int			mLabelOffset;
	int			fromPB;
}
;

