
class TreeList;
class BooleanBipartitionList;

class BipartitionList	{

	public:

	BipartitionList( TreeList* inTreeList, int from = 0, int every = 1, double* probarray = 0);
	BipartitionList( TaxaParameters* inParam);

	~BipartitionList();

	void		Sort(double cutoff = 0);


	Int16 GetSize()	{return mSize;}

	double& 	operator() ( const Bipartition& inPartition );
	void		Append(BooleanBipartitionList* inBBList, double prob = 1);
	void		Append(BipartitionList* bplist);
	void		Append(Bipartition inPartition);
	void		Insert(Bipartition inPartition, double prob, double length);

//	Bipartition&	operator[] (Int16 index) const {return *mBipartitionArray[index];}
	Bipartition&	operator[] (Int16 index)	{return *mBipartitionArray[index];}

	double	GetProb(Int16 index)	const { return mProbArray[index];}
	double	GetLength(int index)	{return mLengthArray[index];}
	Bipartition	GetBipartition(int index)	{return *mBipartitionArray[index];}

	Int32	GetTreeNumber();

	TaxaParameters*			GetParameters()	{ return mParam;}

	void				ToString(ostream& os);
	void				ToString(ostream& os, int* permut, int N);

	void				ReadMrBayes(string filename);
	void				ReadMrBayes(itstream& is);

	void				ReadFromFile(string filename);
	void				ReadFromFile(itstream& is);

	TaxaParameters*			mParam;
	TreeList*			mTreeList;
	Int16				mSize;
	Int16				mAllocatedSize;
	Bipartition**			mBipartitionArray;
	double*				mProbArray;
	double*				mLengthArray;

	static const int		basicsize = 100;
	void				Reallocate();
	
}
;

;
