

const int next = 11;

const string extension[] = {"logsamp", "length", "meanlength", "nmode", "alpha", "statent", "rrent", "meanrate", "rateent","gamma", "pconst"};



const string header = "/baie/home/usertest/bf2/aux/header.tex";
const string modeheader = "/baie/home/usertest/bf2/aux/modeheader";

// amino acids

	const int precision = 10000;
	const string Alphabet = "Amino_Acids";
	const int Nstate = 20;
	const int NstateNstate = 400;
	const char AminoAcids[] = {'A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y','-'};
	const char aminoacids[] = {'a','c','d','e','f','g','h','i','k','l','m','n','p','q','r','s','t','v','w','y','-'};
	const Int16 unknown = -1;

	const int MaxSubNumber = 50;

	const double WAG_RR[] = { 1.02704,0.738998,1.58285,0.210494,1.41672,0.316954,0.193335,0.906265,0.397915,0.893496,0.509848,1.43855,0.908598,0.551571,3.37079,2.12111,2.00601,0.113133,0.240735,0.0302949,0.021352,0.39802,0.306674,0.248972,0.170135,0.0740339,0.384287,0.390482,0.265256,0.109404,0.0988179,0.528191,1.40766,0.512984,1.00214,0.71707,0.543833,6.17416,0.0467304,0.865584,0.930676,0.039437,0.479855,0.0848047,0.103754,5.42942,0.423984,0.616783,0.147304,1.07176,0.374866,0.152335,0.129767,0.325711,0.0811339,0.567717,0.570025,0.127395,2.58443,0.154263,0.315124,0.947198,0.682355,5.46947,0.439157,0.704939,0.822765,0.588731,0.156557,0.196303,0.049931,0.679371,1.05947,0.088836,2.11517,1.19063,0.0961621,0.161444,0.0999208,0.102711,0.545931,0.171903,0.649892,1.52964,6.45428,0.24941,0.0304501,0.373558,0.0613037,0.1741,1.12556,0.24357,0.330052,0.584665,1.34182,0.225833,0.187247,0.336983,0.103604,0.13819,0.890432,0.499462,0.404141,3.95629,0.696198,4.29411,2.13715,0.740169,0.473307,0.118358,0.262569,3.87344,0.323832,3.17097,4.25746,0.554236,0.0999288,0.113917,0.186979,0.31944,1.45816,7.8213,0.212483,0.42017,0.257555,0.934276,3.01201,0.556896,3.8949,5.35142,0.96713,1.38698,0.305434,0.137505,0.133264,4.85402,0.131528,0.415844,0.869489,0.497671,0.344739,0.326622,1.80034,0.665309,0.398618,0.198221,0.171329,1.54526,0.683162,0.493905,1.51612,2.05845,0.515706,0.428437,0.195081,1.54364,0.635346,3.97423,2.03006,0.196246,0.0719167,1.086,0.933372,0.679489,1.61328,0.795384,0.314887,0.139405,0.216046,3.0355,1.02887,0.857928,0.301281,0.215737,0.22771,1.22419,0.554413,0.251849,1.16392,0.381533,4.37802,0.232739,0.523742,0.786993,1.38823,0.110864,0.291148,0.365369,0.31473,2.48539 };

	const double JTT_RR[] = { 56,81,105,15,179,27,36,35,30,54,54,194,57,58,378,475,298,9,11,10,5,78,59,69,17,7,23,31,34,14,9,113,223,42,62,115,209,767,4,130,112,11,26,7,15,528,15,49,16,59,38,31,4,46,5,119,26,12,181,9,18,58,18,323,29,30,32,45,10,7,5,40,89,4,248,43,10,17,4,5,92,12,62,53,536,23,6,27,6,14,81,24,26,137,201,33,47,55,8,16,45,56,33,391,115,597,328,73,46,11,8,573,21,229,479,47,10,9,22,40,245,961,9,32,14,65,263,21,292,646,47,103,14,10,8,388,12,102,72,38,59,25,180,52,24,30,16,43,44,29,226,323,24,18,15,86,45,503,232,16,8,70,164,74,285,118,23,6,10,310,53,51,20,18,24,101,64,17,126,20,477,38,35,63,112,12,21,25,16,71};

	const double JTT_Stat[] = {
0.076748
,0.019803
,0.051544
,0.061830
,0.040126
,0.073152
,0.022944
,0.053761
,0.058676
,0.091904
,0.023826
,0.042645
,0.050901
,0.040752
,0.051691
,0.068765
,0.058565
,0.066005
,0.014261
,0.032102
};

const double WAG_Stat[] = {
0.0866279
,0.0193078
, 0.0570451
, 0.0580589 
, 0.0384319 
, 0.0832518 
, 0.0244313
, 0.048466  
, 0.0620286 
, 0.086209
, 0.0195027 
, 0.0390894 
, 0.0457631 
, 0.0367281 
, 0.043972
, 0.0695179
, 0.0610127
, 0.0708956
, 0.0143859
, 0.0352742
};


	const double mtREV_RR[] = { 59.93,17.67,9.77,6.37,120.71,13.9,96.49,8.36,25.46,141.88,26.95,54.31,1.9,23.18,387.86,480.72,195.06,1.9,6.48,1.9,1.9,70.8,30.71,141.49,62.73,1.9,25.65,6.18,58.94,31.26,75.24,103.33,277.05,179.97,1.9,33.6,254.77,583.55,4.98,56.77,113.99,4.34,2.31,1.9,1.9,794.38,13.43,55.28,1.9,69.02,28.01,1.9,19.86,21.21,2.67,28.28,49.12,3.31,313.86,1.9,1.9,63.05,12.83,313.56,1.9,54.71,14.82,21.14,1.9,13.12,1.9,48.16,84.67,6.44,216.06,90.82,15.2,17.31,19.11,4.69,64.29,33.85,6.35,7.84,465.58,1.9,5.98,22.73,2.41,1.9,53.3,1.9,6.75,23.03,125.93,11.17,2.53,10.92,3.21,12.26,127.67,11.49,11.97,496.13,60.97,582.4,165.23,77.46,44.78,1.9,7.08,670.14,19.57,329.09,517.98,27.1,20.63,8.34,1.9,47.7,368.43,1222.94,1.9,25.01,14.88,91.37,608.7,50.1,465.58,141.4,105.79,136.33,1.9,24,51.17,537.53,15.16,40.1,39.7,15.58,73.61,126.4,91.67,32.44,44.15,65.41,18.84,47.37,1.9,111.16,528.17,387.54,21.71,39.96,73.31,173.56,13.24,494.39,238.46,1.9,10.68,191.36,137.29,23.64,169.9,128.22,8.23,4.21,16.21,220.99,54.11,94.93,19,1.9,38.82,6.04,2.08,7.64,21.95,1.9,597.21,1.9,38.58,64.92,204.54,9.99,38.73,5.37,1.9,26.25};

	const int RandomStart = 1;
	const int CheckLevel = 0;
	const int verbose  = 0;
	const double saw_epsilon = 1e-3;
	const int MaxTopoMoveTypeNumber = 10;
	const int MaxMoveTypeNumber = 50;
	const int MaxSuperMoveTypeNumber = 10;
	const int MaxChainNumber = 100;

	const double	entropy_epsilon = 1e-6;

	enum MultiplicativeResampling {ExpoResampling, GammaResampling};

	const string EndOfObject = "##END## ";

	enum	InitMode 	{	Random = 0,
					Uniform = 1,
					Empirical = 2,
					Poisson = 3,
					JTT = 4,
					mtREV = 5,
					WAG =6,
					dayhoff = 7,
					Fixed = 8,
					Error = 9
				};

	enum	Switch		{No = 0, Yes = 1};

	enum 	Prior 		{Flat = 0, PowerLaw = 1, GammaInv = 2, Dirichlet = 3 , MultiGamma = 4, Exponential = 5, OnOff = 6, GammaDistributed = 7, Dirac = 8, GammaMixture = 9, AlphaBased = 10, BetaBased = 11, Trapezoidal = 12};

	enum	ModelSwitchMode	{None = 0, Thermo = 1, RAS = 2 , SUB = 3, Hetero = 4, RateAlphaParameter = 5, InternalBranchLength = 6, TREE = 7};

	enum	MCMCMCType {BetaMCMCMC = 0, ZetaMCMCMC = 1, JacknifeMCMCMC = 3};

	enum	HeterotachyMode {SchadtLange = 0, Covarion = 1, BranchRateHeterotachy = 2};

	enum	HeterogeneityMode {SameProb = 0, SiteProb = 1, BranchProb = 2};

	enum 	MoveType  {			Global =                0,
						Local =                 1,
						NodeSliding = 		2,

						TreeLength =            3,
						OneBranchLength =       4,
						AllBranchLength =       5,

						DirRate =               6,
						Rate =                  7,
						Gamma =                 8,
						Pconst =                9,

						RefStationaryM   =      10,
						RefStatCenterM =        11,
						RefStatAlphaM =         12,
						RefRelativeRate	=       13,

						ModeStationary =        14,
						ModeStatCenterM =       15,
						ModeStatAlphaM =        16,
						ModeRelativeRate=      17,

						SwitchMode =           18,
						Alpha =                19,

						FastBranchLength = 20,
						FastRate = 21,

						SwitchModeIntegralOld = 22,
						SplitMergeIntegral = 23,
						AlphaIntegral = 24,

						ResampleStatMove = 25,
						ResampleStateMove = 26,
						ResampleSubMove = 27,

						FastDirRate = 28,
						FastNodeSliding = 29,
						FastLocal = 30,

						RateVar = 31,
						Xi = 32,
						Delta = 33,
						S01 = 34,
						S10 = 35,
						DirRateVar = 36,
						BranchRate = 37,
						BranchSwitch = 38,
						InvProb = 39,

						FastBranchRate = 40,
						FastBranchSwitch = 41,
						
						ModeRateM = 42,
						RateSwitchMode = 43,
						RateAlphaM = 44,
						ModeRateEx = 45,
						RateSwitchModeEx = 46,
						RateGammaM = 47,
						FastModeRateEx = 48,
						FastRateSwitchModeEx = 49,
						RateSwitchModeIntegral = 50,
						ResampleRateMove = 51,
						SwitchModeIntegral = 52,
						ModeStationaryEx = 53,
						MeanLengthM = 54


			};

	const int ConstMoveTypeNumber = 55;

	const int AssumeStat[] =            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1};
	const int AssumeState[] =           {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,0,1,0,0,0};
	const int AssumeSub[] =             {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0};
	const int AssumePruningLogSamp[] =  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,1,0,0,0,0,0,1,1};
	const int AssumeFastLogSampling[]=  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0};

	const int CorruptStat[] =           {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	const int CorruptState[] =          {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,0,0,0,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,0,0,0,1,1};
	const int CorruptSub[] =            {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,0,0,0,1,1};
	const int CorruptPruningLogSamp[]=  {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,1,1,1,0,0};
	const int CorruptFastLogSampling[]= {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,0,1,1,1,1,1,1,1,1,1,0,0,1,1,1,1,1,0,0,0,1,1,1,1,1};

	const int HasDelta[] =              {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,1,0,0,1,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,0,1,1,0,0,0,0,1,1};
	const int HasN[] =                  {0,0,0,0,0,0,1,1,0,0,1,1,0,1,1,1,0,1,1,0,1,1,0,0,0,0,0,0,1,0,0,1,0,0,0,0,1,0,0,0,1,1,0,1,0,0,1,0,1,1,1,0,1,1,0};

	enum	TopoMoveType	{
						FixedTopo = 0,
						Neighbor = 1,
						DetachGroup = 2,
						CollSplit1 = 3,
						CollSplit3 = 4
				};

	const string TopoMoveTypeName[] =	{
						"FixedTopo",
						"Neighbor",
						"DetachGroup",
						"CollSplit1",
						"CollSplit3"
				};


	const string MoveTypeName[] =  {
						"Global",
						"Local",
						"NodeSliding",

						"TreeLength",
						"OneBranchLength",
						"AllBranchLength",

						"DirRate",
						"Rate",
						"Gamma",
						"Pconst",

						"RefStationary",
						"RefStatCenter",
						"RefStatAlpha",
						"RefRelativeRate",

						"ModeStationary",
						"ModeStatCenter",
						"ModeStatAlpha",
						"ModeRelativeRate",

						"SwitchMode",
						"Alpha",

						"FastBranchLength",
						"FastRate",

						"SwitchModeIntegralOld",
						"SplitMergeIntegral",
						"AlphaIntegral",

						"ResampleStat",
						"ResampleState",
						"ResampleSub",
						
						"FastDirRate",
						"FastNodeSliding",
						"FastLocal",

						"RateVar",
						"Xi",
						"Delta",
						"S01",
						"S10",
						"DirRateVar",
						"BranchRate",
						"BranchSwitch",
						"InvProb",

						"FastBranchRate",
						"FastBranchSwitch",
						"ModeRateM",
						"RateSwitchMode",
						"RateAlphaM",
						"ModeRateEx",
						"RateSwitchModeEx",
						"RateGammaM",	
						"FastModeRateEx",
						"FastRateSwitchModeEx",
						"RateSwitchModeIntegral",
						"ResampleRate",
						"SwitchModeIntegral",
						"ModeStationaryEx",
						"MeanLength"
					};



// defaults


	const InitMode DefaultInitTree = Random;
	const InitMode DefaultInitBranchLength = Random;
	const double DefaultInitInternalLength = 0.1;
	const double DefaultInitLeafLength = 0.1;

	const InitMode DefaultInitRate = Uniform;
	const InitMode DefaultInitRateVar = Uniform;
	const InitMode DefaultInitGamma = Fixed;
	const InitMode DefaultInitDelta = Fixed;
	const InitMode DefaultInitXi = Fixed;
	const InitMode DefaultInitPconst = Fixed;
	const double DefaultInitGammaValue = 1;
	const double DefaultInitDeltaValue = 1;
	const double DefaultInitXiValue = 1;
	const double DefaultInitPconstValue = 0;

	const InitMode DefaultInitRefRR = JTT;
	const InitMode DefaultInitRefStat = Empirical;
	const InitMode DefaultInitRefStatCenter = JTT;
	const InitMode DefaultInitRefStatAlpha = Fixed;
	const double DefaultInitRefStatAlphaValue = 1;

	const InitMode DefaultInitModeRR = Poisson;
	const InitMode DefaultInitModeStat = Empirical;
	const InitMode DefaultInitModeStatCenter = JTT;
	const InitMode DefaultInitModeStatAlpha = Fixed;
	const double DefaultInitModeStatAlphaValue = 1;

	const InitMode DefaultInitModeAffiliation = Random;
	const InitMode DefaultInitAlpha = Fixed;
	const double DefaultInitAlphaValue = 1;
	const InitMode DefaultInitNmode = Fixed;
	const int  DefaultInitNmodeValue = 1;

	const Prior DefaultAlphaPrior = Flat;		//flat
	const double DefaultAlphaMin = 0.01;
	const double DefaultAlphaMax = 1000;

	const Prior DefaultLengthPrior = Exponential;		// flat
	const double DefaultLengthMin = 0.01;
	const double DefaultLengthMax = 10;

	const Prior DefaultRatePrior = Dirichlet;		// flat
	const double DefaultRateMin = 1e-4;
	const double DefaultRateMax = 100000;
	const double DefaultGammaMin = 0.1;
	const double DefaultGammaMax = 50;
	const double DefaultDeltaMin = 0.01;
	const double DefaultDeltaMax = 100;
	const double DefaultXiMin = 0.1;
	const double DefaultXiMax = 10;

	const double DefaultStatMin = 1e-7;
	const double DefaultStatMax = 20000;
	const Prior DefaultRefStatPrior = Flat;		// flat
	const Prior DefaultModeStatPrior = Flat;	// flat

	const double DefaultStatAlphaMin = 0.1;
	const double DefaultStatAlphaMax = 1000;

	const ModelSwitchMode DefaultModelSwitchMode = None;

	const int DefaultInvTemp = 1;
	const int DefaultRASModelSwitch = 1;
	const int DefaultSUBModelSwitch = 1;
	const int DefaultHeteroModelSwitch = 0;

	const Switch DefaultNormalise = Yes;
	const Switch DefaultDeleteConstant = No;
	const Switch DefaultSavePartialLogLikelihoods = No;

	const Switch DefaultModeFastCompute = Yes;
	const Switch DefaultRefFastCompute = Yes;

	const double DefaultTooSmall = 1e-320;
	const double DefaultTooLarge = 1e6;
	const double DefaultInfProb = 1e6;

	const double DefaultSwapFreq = 0.1;
