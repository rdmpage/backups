
class MCParameters;
class PhyloBayes;

class Sample	{


	public :

			Sample(string inSampleName);
			Sample(string inChainName, int burnin, int every, int until = -1);
			~Sample();

	double		logDetCovLength();
	double		logPostL();

	MCParameters*	GetParameters()	{return mParam;}
	int		GetSize()	{return mSize;}
	int		GetChainNumber()	{return Nchain;}

	PhyloBayes*	GetNextPB();


	// private :

	void		OpenChainStream();

	int		mSize;
	MCParameters*	mParam;
	int		Nchain;

	int		Burnin;
	int		Every;

	int		extract;
	icstream*	Sample_is;
	icstream*	Chain_is;

	string 		SampleName;
	string		ChainName;

	PhyloBayes*	currentPB;
	PhyloBayes*	pb;

	int		currentChain;
	int		currentIndex;

	int 		eof;

	void		SUBThermo();

	int		Read(int lengths = 0, int rates = 0, int modes = 0, int cons = 0);
	int		CrossValidation(string InitFile, int nrep , double& mean, double& var, double* array = 0);
	
	void		LooCV1(double& mean, double& var, double* array = 0);
	void		LooCV2(int nrep, double& mean, double& var, double* array = 0);

	int		ReadModeRates(
				int ncat, double min, double max,
				double& LogSampling, double& LogSamplingError, double& EffectiveLength, double& EffectiveLengthError,
				double& NRateMode, double& NRateModeError, double& RateAlpha, double& RateAlphaError, double& RateGamma, double& RateGammaError,
				double* EffLength, double* EffLengthError, double* RateHisto, double* Rate, double* RateError);

	double** 	ReadModeAff(int& Nmode);

	double 		DecorrelTime();
	

	void		SimuData(string outfile);
	double		HarmonicMean();
	// double		HarmonicMean(double delta, int nrep, int refstat, int nmode, int moderr, int modestat);

	double		FollowBLGradient(double delta, int nrep);
	double		GibbsUpdateBranchLengths(int nrep);
	double		GibbsUpdateBranchLengthsAndAlpha(int nrep);
	double		NewtonAlpha(double K, double espilon);
	double		LogDetCov(int nrep);	
}

;

