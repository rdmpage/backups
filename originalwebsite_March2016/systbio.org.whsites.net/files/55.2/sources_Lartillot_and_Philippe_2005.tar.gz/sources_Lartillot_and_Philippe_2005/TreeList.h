
class TaxaParameters;
class Tree;
class PolyNode;
class Bipartition;
class PhyloBayes;

class TreeList	{


	public:

					TreeList(TaxaParameters* inParam, Int16 inSize);
					TreeList();
					TreeList(string filename);

					~TreeList();

	//void			Select(Bipartition inPartition);			// eliminate trees not compatible with inPartition
	//void			Eliminate(Bipartition inPartition);			// remove the species designated by the Bipartition
																// in which the bipartition is eliminated
	Tree*			GetTree(Int16 index);

	Int32			GetSize()	{return mSize;}

	TaxaParameters*		GetParameters()	const {return mParam;}

	// append trees and eliminate some ?

	void			ToMrBayes(ostream& os, int every = 1);
	void			ReadMrBayes(itstream& is, int Ntaxa, int size);
	void			ReadMrBayes(string filename);


	TaxaParameters*		mParam;
	Int16 			mSize;
	Tree**			mTreeArray;

	friend double		BPCompare(TreeList** list, int P, int& MaxTime, ostream* osp = 0, double cutoff = 0.10, int detailed = 1);
	friend double		QuartetCompare(TreeList* list1, TreeList* list2, ostream* osp = 0, double cutoff = 0, int withChanges = 0);
}
;


