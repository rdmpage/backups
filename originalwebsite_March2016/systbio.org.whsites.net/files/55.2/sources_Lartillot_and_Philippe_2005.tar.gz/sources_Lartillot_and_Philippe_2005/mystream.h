
#include <iostream>
#include <iomanip>
#include <fstream>
#include "types.h"
#include "mystring.h"

// using namespace std;

#define ostream std::ostream
#define ofstream std::ofstream
#define istream std::istream
#define ifstream std::ifstream
#define cerr std::cerr
#define cout std::cout
#define setw std::setw
#define ostringstream std::ostringstream
#define istringstream std::istringstream
#define IOS_APPEND std::ios_base::app

enum Manipulator  {FLUSH , CLOSE, TAB, LINE};

enum StreamMode  {tab_delimited, space_filled};

enum FileMode {		OVERWRITE = 0,
					APPEND = 4 };

const int default_precision = 8;
const int default_justification = 10;

const int MaxPrecision = 20;
const int MaxJustification = 20;


// exceptions

class StreamException {

	public :

		StreamException(string);
		StreamException(char*);
//		~StreamException();

	void	push(string);
	void	publish(ostream& os);

	private :

	string	comment;
};


// otstream

class otstream : public ofstream 	{

	public :

			otstream(string filename, FileMode = OVERWRITE);
			otstream(string basename, string extension, FileMode = OVERWRITE);

	void		setprecision(int inprec);
	void		setjustification(int injust);
	void		setformat(StreamMode inmode);
	void		setformat(StreamMode inmode, int inprec, int injust);
	void		close();

	friend 	otstream& operator<<(otstream& ots, int in);
	friend 	otstream& operator<<(otstream& ots, int16 in);
	friend 	otstream& operator<<(otstream& ots, int32 in);
	friend  otstream& operator<<(otstream& ots, double in);
	friend  otstream& operator<<(otstream& ots, float in);
	friend  otstream& operator<<(otstream& ots, char in);
	friend  otstream& operator<<(otstream& ots, const char* in);
	friend  otstream& operator<<(otstream& ots, string in);
	friend  otstream& operator<<(otstream& ots, Manipulator in);


	char 		space;
	StreamMode 	format;
	int 		precision;
	int			justification;

};


class itstream : public ifstream	{

	public :

			itstream(string filename);
			itstream(string filename, string extension);

	int		GoPastNext(char);
	string	ReadLine();
	void	GoPastNextWord(string);
	void	GoPastNextLine(string);

	int		eof();
	char	SkipSeparators();

	friend itstream& operator>>(itstream& ics, int& in);
	friend itstream& operator>>(itstream& ics, int16& in);
	friend itstream& operator>>(itstream& ics, int32& in);
	friend itstream& operator>>(itstream& ics, double& in);
	friend itstream& operator>>(itstream& ics, float& in);
	friend itstream& operator>>(itstream& ics, char& in);
	friend itstream& operator>>(itstream& ics, char* in);
	friend itstream& operator>>(itstream& ics, string& in);

};

// ocstream

class ocstream : public ofstream 	{

	public :

				ocstream(string filename, FileMode = APPEND);
 		  		ocstream(string basename, string extension, FileMode = APPEND);
	void		close();

	ocstream& 	putarray(int* in, int size);
	ocstream& 	putarray(int16* in, int size);
	ocstream& 	putarray(int32* in, int size);
	ocstream& 	putarray(float* in, int size);
	ocstream& 	putarray(double* in, int size);

	friend 	ocstream& operator<<(ocstream& ocs, int16 in);
	friend 	ocstream& operator<<(ocstream& ocs, int32 in);
	friend	ocstream& operator<<(ocstream& ocs, int in);
	friend  ocstream& operator<<(ocstream& ocs, double in);
	friend  ocstream& operator<<(ocstream& ocs, float in);
	friend  ocstream& operator<<(ocstream& ocs, char in);
	friend  ocstream& operator<<(ocstream& ocs, char* in);
	friend  ocstream& operator<<(ocstream& ocs, string in);
	friend  ocstream& operator<<(ocstream& ocs, Manipulator in);

};

class icstream	: public ifstream	{

	public :

			icstream(string filename);
			icstream(string filename, string extension);

	icstream& getarray(int* in, int size);
	icstream& getarray(int16* in, int size);
	icstream& getarray(int32* in, int size);
	icstream& getarray(float* in, int size);
	icstream& getarray(double* in, int size);

	friend icstream& operator>>(icstream& ics, int16& in);
	friend icstream& operator>>(icstream& ics, int32& in);
	friend icstream& operator>>(icstream& ics, int& in);
	friend icstream& operator>>(icstream& ics, double& in);
	friend icstream& operator>>(icstream& ics, float& in);
	friend icstream& operator>>(icstream& ics, char& in);
	friend icstream& operator>>(icstream& ics, char* in);
	friend icstream& operator>>(icstream& ics, string& in);
	friend icstream& operator>>(icstream& ics, Manipulator in);

};
