
#include <time.h>
#include <sys/stat.h>
#include <sys/times.h>
#include <math.h>

#include "mystream.h"
#include <sstream>

