

// Redefining the types used in the MacOS 9 / CodeWarrior version


typedef int Int16;
typedef long int Int32;

typedef short int16;
typedef long int32;

typedef int Boolean;

const int nil = 0;
