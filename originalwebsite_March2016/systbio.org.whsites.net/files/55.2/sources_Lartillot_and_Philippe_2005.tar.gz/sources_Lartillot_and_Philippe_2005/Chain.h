
class MCParameters;

class Chain	{

	public:

			Chain(string Name); 			// read a chain from file,
			Chain(string InitFile, string Name, string inPath = "./"); 	// make a new chain
			Chain(string Name, int a, string inPath);
			Chain(MCParameters* param, string Name);
			~Chain();


	void		MakeFiles();
	int		RunningStatus();
	int		Run();
	int		Start();

	int 		Monitor(int verbose=0, int latex=1, int keep=0, int update=0);
	double 		AutoCorrel(int burnin);

	MCParameters*	GetParameters()	{return mParam;}
	string		GetName()	{return ChainName;}

	string ChainName;
	MCParameters* mParam;

};

