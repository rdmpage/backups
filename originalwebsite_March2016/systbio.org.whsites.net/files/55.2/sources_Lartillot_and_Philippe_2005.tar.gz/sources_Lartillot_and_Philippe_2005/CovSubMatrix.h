

class SubMatrix;

class CovSubMatrix		{

	public:

			CovSubMatrix(SubMatrix* inSubMatrix, double* s01, double* s10);
			~CovSubMatrix();


	void		Copy(CovSubMatrix* from);

	int 		ComputeArray();
	int 		Diagonalise();

	void		ComputeExponential(double range, double** expo);
	double**	GetGenerator()	{return Q;}

	double 	EigenValue(int i) { return v[i];}

	// access to matrix Q colums and rows
	inline double& operator()(int i, int j);			//
	inline double& operator()(int i, int j) const ;


	void	CheckDiag();

	//-------------
	// data fields
	//-------------

	double* mArray;

	// matrices as lists of rows
	// Q : the infinitesimal generator matrix
	// a : the copy of it -> to feed linalg ( as a list of rows)
	// v : eigenvalues
	// vi : imaginary part
	// u : the matrix of eigen vectors
	// invu : the inverse of u
	// wi : work vector
	// w : work vector
	//
	// total : 4 Nstate*Nstate + 4 * Nstate

	double ** Q;
	double ** a;
	double ** u;
	double ** invu;
	double * v;
	double * vi;

	int N;
	int NN;
	
	SubMatrix* mSubMatrix;
	double* s01;
	double* s10;
};
