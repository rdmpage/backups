
#include <string>

#define string std::string

const char digit[10] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

const char _tab = '\t';
const char _empty = 'o';
const char _line = '\n';


int	IsInt(string s);
int IsFloat(string s);

int Int(string s);
double Double(string s);

int EmptyLine(string s);
int IsDigit(char c);

string StringReplace(char c, string by, string s);

string Filter(string input, char c);

