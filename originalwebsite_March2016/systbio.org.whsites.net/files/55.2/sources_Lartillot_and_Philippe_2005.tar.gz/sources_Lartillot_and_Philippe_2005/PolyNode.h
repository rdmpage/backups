
class BooleanBipartitionList;
class Bipartition;
class TreeList;

class Consensus;
class Tree;

class PolyNode	{

	public:

	PolyNode();
	PolyNode(int inLabel, int inLevel = -1);

	~PolyNode();
	// deletion is not recursive

	void		deleteRecursive();
	// accessors

	PolyNode*	Up()	{return up;}
	PolyNode*	Down()	{return down;}
	PolyNode*	Next()	{return next;}
	PolyNode*	Prev()	{return prev;}

	int			IsLeaf() {return (down == 0);}
	int			IsRoot() {return (up == 0);}

	int			GetDegree() {return degree;}
	int			CheckDegree();
	int			IsDichotomous();

	int 			GetLabel() {return label;}
	void			SetLabel(int inLabel)	{ label = inLabel;}

	void			SetSpeciesNames(string* names);

	string			GetName()	{return name;}
	void			SetName(string inName)	{ name = inName;}

	double			GetBranchLength()	{return branchLength;}
	void			SetBranchLength(double inBranchLength)	{branchLength = inBranchLength;}

	double			GetProb()	{return mProb;}
	void			SetProb(double inProb)	{mProb = inProb;}

	void			SetTree(Tree* inTree)	{mTree = inTree;}
	Tree*			GetTree()	{return mTree;}

	void			Detach();
	void			DetachAndRemove(); // this one also removes the up node, if it ends up with only one descendant
	PolyNode*		AttachTo(PolyNode* inNode);

	int 			ComputeMinLeafLabel();

	void			DetachOld(PolyNode* inNode);
	void			Insert(PolyNode* inNode);	// will be inserted as the last one


	int			RegisterWithData(int& currentLabel, string* SpeciesNames, int Ntaxa);
	int			Dichotomise();
	void			SetSuper(Tree* inTree);			// recursive 

	int			GetSize();
	double			GetDepth();
	int			GetIntDepth();
	void			ComputeSizeAndDepth();
	void			SetFormalBranchLengths(double scale, int order);

	void			GetSpeciesNames(string* name, int& index);

	PolyNode*		FlipFlop();		// return the node that has been excluded, if any...

	PolyNode*		FindNode(Bipartition& inPartition, Boolean& Orientation);

	PolyNode*		FindNodePruning(Bipartition& inPartition,
										Boolean& Orientation,
										Bipartition& outPartition);

	Bipartition		GetBipartition();
	Bipartition		BipartitionPruning(BooleanBipartitionList* inBBList);

	Int16			Analyse(Bipartition& inPartition);
	void			Insert(Bipartition& inPartition, double prob, double length);


	double			Draw(ostream& os, double scaleX, double scaleY, int withProbs, int withSpeciesNames, int withInternalLabels);

	void			TranslateLabels(int offset);

	void 			Phylip(ostream& os, int withLengths = 0, int withProbs = 1, int withSpeciesNames = 1, int withInternalLabels = 0);

	Tree* 	mTree;

	PolyNode* up;
	PolyNode* down;
	PolyNode* next;
	PolyNode* prev;


	int label;
	int degree;

	int value;

	string name;

	double branchLength;
	double mProb;

	int 	size;
	int	intdepth;
	double	depth;

	double X;
	double Y;
	double Y2;
}
;
