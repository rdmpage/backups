class PolyNode;

class PhyloBayes	{

	public :

		//-------------
		// member functions
		//-------------


		// constructing / destructing / cloning

						PhyloBayes(MCParameters* inParam);			// constructor
						~PhyloBayes();								// destructor

		void				DrawFromPrior(int, int, int, int); // assume topology is fixed
		void				CreateModeStationaries();
		void				CreateRefStationaries();
		void				CreatePartialLikelihoods();

		PhyloBayes&			Clone(PhyloBayes& from, int CloningMode);	// clone . CloningMode = 1 : full copy
		void				CloneSub(PhyloBayes* from);
		void				CloneSiteSub(PhyloBayes* from);
		void				CloneStat(PhyloBayes* from);
		void				CloneState(PhyloBayes* from);
		void				CloneLogProbs(PhyloBayes* from);
		void				CloneMode(PhyloBayes* from, int mode);
		void				CloneFastLogSampling(PhyloBayes* from);
		AmphiNode* 			cloneTree(AmphiNode* inTree, AmphiNode* fromTree, AmphiNode* fromRoot);
		void				SetTree(AmphiNode* fromTree, AmphiNode* fromRoot);
		void				ClonePartials(PhyloBayes* from, const AmphiNode* node, int atSite);
		void				ClonePartials(PhyloBayes* from, const AmphiNode* node);
		void				ClonePartialsForAllNodes(PhyloBayes* from, int atSite);
		void				ClonePartialsForAllNodes(PhyloBayes* from);

		void				FastCloneBranchRates(PhyloBayes* from, AmphiNode* node, int site);
		void				CloneBranchRates(PhyloBayes* from, int site);
		void				CloneBranchRates(PhyloBayes* from);
		void				CloneBranchSwitches(PhyloBayes* from, int site);
		void				CloneBranchSwitches(PhyloBayes* from);

		void				CloneCov(PhyloBayes* from);
		void				CloneCov(PhyloBayes* from, int site);

		// Updates

		void				Update();

		void				UpdateCov();
		void				UpdateCov(int site);

		void				UpdateModes();
		void				UpdateModeTotal();
		void				UpdateModeTotal(int mode);
		void 				UpdateRefZip(int i);
		void				UpdateRefZipForAllSites();
		void 				UpdateZip(int i);
		void				UpdateZipForAllSites();

		void				ComputeRefRateFactor();
		void				ComputeRateFactor(int i);
		void				ComputeRateFactorForAllModes();
		void				UpdateLogProbs();

		void				UpdateOnOff();
		void				UpdateOnOff(int site);

		void				UpdateRates(int site);
		void				UpdateRates(int site, AmphiNode* node);
		void				FastUpdateRates(int site, AmphiNode* node);
		void				UpdateRates();
		void				UpdateNswitch();
		void				UpdateNon();


		//accessors

		MCParameters*			GetParameters()	{return mParam;}
		double				GetBeta() {return Beta;}
		double				GetZeta() {return Zeta;}
		void				SetBeta(double inBeta);
		void				SetZeta(double inZeta);
		void				SetData(int chain);

		SubMatrix*			GetSubMatrix() {return mSubMatrix;}
		Node* 				GetRoot()	{return (Node*) root;}
		double				GetLength()	{return root->getLength();}
		double&				GetBranchLength(int i)	{ return tree[i].branchLength;}
		double				GetInternalLength();
		double				GetRate(int i) {return rate[i];}
		double				GetEffectiveRate(int i);
		Int32 				GetModeNumber() {return Nmode;}
		int				GetMode(int site)	{return Mode[site];}
		Int32 				GetSiteNumber(int mode) {return SiteNumber[mode]; }
		double				GetAlpha() { return alpha;}
		double				GetGamma() { return gamma;}
		double				GetPconst() { return pconst;}
		double*				GetStationaries(int i);
		double&				GetStationary(int i, int j);
		double				GetSiteStationary(int i, int j);
		double&				GetRefRR(int i, int j);
		double&				GetModeRR(int i, int j);
		SubMatrix*			GetSubMatrix(int mode)	{return mMatrixArray[mode];}


		void				SwapMatrices(PhyloBayes* from);
		// marginals for monitoring

		double				GetStationaryEntropy();
		double				GetRREntropy();
		double 				GetRateEntropy();
		double 				GetRateVarEntropy();
		double				GetMeanRate();
		double				GetMeanBranchRate();
		double				GetMeanBranchRate(int site);
		double				GetMeanXi();


		// checks

		int 				CheckBranchLengths();
		int				CheckModeIdentity(PhyloBayes& from);
		int				CheckModes();
		int				CheckRateModeIdentity(PhyloBayes& from);
		int				CheckRateModes();
		int				SameTopology(PhyloBayes* with);
		int				CheckLogSampling(PhyloBayes* with);
		int				CheckClonality(PhyloBayes* with);


		// streams

		void				InitFromStream(itstream& is);

		void				ReadTree(itstream& is);
		void				ReadBranchLengths(itstream& is);

		void				ReadRates(itstream& is);
		void				ReadBranchRates(itstream& is);
		void				ReadRateVariations(itstream& is);
		void				ReadGamma(itstream& is);
		void				ReadRateGamma(itstream& is);
		void				ReadDelta(itstream& is);
		void				ReadXi(itstream& is);
		void				ReadPconst(itstream& is);

		void				ReadStationaries(double* stat, itstream& is);
		void				ReadRefRR(itstream& is);
		void				ReadRefStationaries(itstream& is);
		void				ReadRefStatCenter(itstream& is);
		void				ReadRefStatAlpha(itstream& is);

		void				ReadModeRR(itstream& is);
		void				ReadModeStationaries(itstream& is);
		void				ReadModeStatCenter(itstream& is);
		void				ReadModeStatAlpha(itstream& is);

		void				ReadModeAffiliations(itstream& is);
		void				ReadAlpha(itstream& is);
		void				ReadRateAlpha(itstream& is);
		void				ReadNmode(itstream& is);
		void				ReadNRateMode(itstream& is);


		void				Initialise();


		void				SetTree(InitMode inMode);
		void				SetTree(Tree& tree);
		void				SetTree(itstream& is);
		void				MakeRandomTree();
		void				SetBranchLengths(InitMode inMode);
		void				MakeRandomBranchLengths();

		void				SetRates(InitMode inMode);
		void				SetBranchRates(InitMode inMode);
		void				SetRateVariations(InitMode inMode);
		void				SetGamma(InitMode inMode);
		void				SetRateGamma(InitMode inMode);
		void				SetDelta(InitMode inMode);
		void				SetXi(InitMode inMode);
		void				SetPconst(InitMode inMode);

		void				SetRelativeRates(double* rr, InitMode inMode);
		void				SetStationaries(double* stat, InitMode inMode);
		void				MakeRandomStationaries(double* stat, Prior prior, double* center, double alpha);
		void				SetModeStatAlpha(InitMode inMode);
		void				SetRefStatAlpha(InitMode inMode);

		void				SetModeAffiliations();
		void				SetAlpha(InitMode inMode);
		void				SetRateAlpha(InitMode inMode);
		void				SetNmode(InitMode inMode);
		void				SetNRateMode(InitMode inMode);


		// reading and writing trees

		void				Phylip(ostream& os, int withLengths = 1, int withProbs = 0, int withSpeciesNames = 0, int withInternalLabels = 0);
		void				ToMrBayes(ostream& os);
		void				ReadPhylipFromFile(string filename);
		void				ReadPhylipFromStream(itstream& is);
		void				TraversePolyNode(PolyNode* inNode);
		AmphiNode*			FindRoot();
		void				Trichotomise();
		void				SwapNodes(AmphiNode* node1, AmphiNode* node2);

		// text streams
		friend otstream&		operator<<(otstream& os,  PhyloBayes& state);
		friend itstream& 		operator>>(itstream& is, PhyloBayes& state);

		// compact streams
		friend ocstream&		operator<<(ocstream& os,  PhyloBayes& state);
		friend icstream& 		operator>>(icstream& is, PhyloBayes& state);


		double				logPrior();
		double				logLengthPrior();
		double 				logAlphaPrior();
		double 				logGammaPrior();
		double 				logMeanLengthPrior();

		double 				logRatePrior();
		double 				logRatePrior(int site);
		double 				logRatePrior(double rate);
		double 				logDPRatePrior(int site);
		double				logGammaMixtureRatePrior(double r);
		double				logFlatRatePrior(double r);
		double				logTrapezoidalRatePrior(double r);
		double				DrawRate();
		double				DrawDPRate();
		double				DrawYangRate();

		double 				logRateVarPrior();
		double 				logRateVarPrior(int site);

		double				DrawBranchRate(int site);

		double				logBranchRatePrior();

		double				logOnOffBranchRatePrior();
		double				logOnOffBranchRatePrior(int site);

		double				logGammaBranchRatePrior();
		double				logGammaBranchRatePrior(int site);
		double				logGammaBranchRatePrior(double rate, int site);

		double				logBranchSwitchPrior();
		double				SiteLogBranchSwitchPrior(int site);
		double				BranchLogBranchSwitchPrior(int branch);


		double 				logMultiGammaStatPrior(double* stat, double* center, double alpha);
		double				logModeStatPrior(int mode);
		double				logModeStatPrior2(int mode);
		double				logModeStatPrior();
		double				logModeStatPrior2();
		double				logRefStatPrior();

		double 				InfiniteLogSampling();
		double 				logSampling(AmphiNode* node = 0);
		double				ModeLogSampling(int mode);
		double				ModeLogSampling();

		double				RateModeLogSampling();
		double				RateModeLogSampling(int mode);

		double				logSamplingTree1();
		double				logSamplingTree2();
		double				logSamplingRAS();
		double				logSamplingUNI();
		double				logSamplingRef();
		double				logSamplingMode();
		double				logSamplingModeZipHeteroMixture();
		double				logSamplingModeMatrixHeteroMixture();
		double				logSamplingHomotache();
		double				logSamplingHeterotache();

		double				PushLogSamplingRAS(double* array);
		double				PushLogSamplingUNI(double* array);
		double				PushLogSamplingRef(double* array);
		double				PushLogSamplingMode(double* array);
		double				PushLogSamplingHomotache(double* array);
		double				PushLogSamplingHeterotache(double* array);
		double				PushLogSamplingModeZipHeteroMixture(double* array);
		double				PushLogSamplingModeMatrixHeteroMixture(double* array);

		double				SiteLogSampling(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRAS(int site, AmphiNode* node = 0);
		double				SiteLogSamplingUNI(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRef(int site, AmphiNode* node = 0);
		double				SiteLogSamplingMode(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRefZip(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeZip(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeZipHeteroMixture(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeMatrixHeteroMixture(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRefMatrix(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeMatrix(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRefHeterotache(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeHeterotache(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRefZipHeterotache(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeZipHeterotache(int site, AmphiNode* node = 0);
		double				SiteLogSamplingRefMatrixHeterotache(int site, AmphiNode* node = 0);
		double				SiteLogSamplingModeMatrixHeterotache(int site, AmphiNode* node = 0);
		double				GetSiteLogSampling(int i) 	{ return mSiteLogSampling[i];}

		double 				logPosterior(AmphiNode* node = 0);
		double				DetailedLogPosterior();

		// Felsenstein pruning algorithm implementation

		void				SetEigenPointers(SubMatrix* inMatrix);
		void				SetEigenPointers(CovSubMatrix* inMatrix);

		void				pruning(const AmphiNode* node, int atSite);
		void				betaPruning(const AmphiNode* node, int atSite);

		void				pruningZip(const AmphiNode* node, int atSite, int withPartials=0, int retro=0);
		void				betaPruningZip(const AmphiNode* node, int atSite, int withPartials=0, int retro=0);

		void				pruningMatrix(const AmphiNode* node, int atSite, int withPartials=0, int retro=0);
		void				pruningCovMatrix(const AmphiNode* node, int atSite, int withPartials=0, int retro=0);
		void				betaPruningMatrix(const AmphiNode* node, int atSite, int withPartials=0, int retro=0);

		void				pruningAncestral(const AmphiNode* node, int atSite);
		void				betaPruningAncestral(const AmphiNode* node, int atSite);

		void				pruningAncestralZip(const AmphiNode* node, int atSite);
		void				pruningAncestralZipBranchRate(const AmphiNode* node, int atSite);
		void				pruningAncestralZipHeteroMixture(const AmphiNode* node, int atSite);
		void				pruningAncestralZipRASMixture(const AmphiNode* node, int atSite);
		void				betaPruningAncestralZip(const AmphiNode* node, int atSite);

		void				pruningAncestralMatrix(const AmphiNode* node, int atSite);
		void				pruningAncestralMatrixBranchRate(const AmphiNode* node, int atSite);
		void				pruningAncestralMatrixHeteroMixture(const AmphiNode* node, int atSite);
		void				pruningAncestralMatrixRASMixture(const AmphiNode* node, int atSite);

		void				pruningZipHeteroMixture(const AmphiNode* node, int atSite, int withPartials = 0, int retro = 0);
		void				pruningZipRASMixture(const AmphiNode* node, int atSite, int withPartials = 0, int retro = 0);
		void				pruningZipHeterotache(const AmphiNode* node, int atSite);
		void				pruningZipBranchRate(const AmphiNode* node, int atSite, int withPartials = 0, int retro = 0);
		void				pruningMatrixHeteroMixture(const AmphiNode* node, int atSite, int withPartials = 0, int retro = 0);
		void				pruningMatrixRASMixture(const AmphiNode* node, int atSite, int withPartials = 0, int retro = 0);
		void				pruningMatrixHeterotache(const AmphiNode* node, int atSite);
		void				pruningMatrixBranchRate(const AmphiNode* node, int atSite, int withPartials = 0, int retro = 0);

		void				SimuPruningMatrix(const AmphiNode* node, int atSite, int state);
		void				SimuPruningZip(const AmphiNode* node, int atSite, int state);

		int**				SimulateData(int withCurrentRates);

		double				Move(MoveType moveType, double delta, int N, PhyloBayes* copy);

		double				localMove(double lambda, PhyloBayes* BackUp);
		double				globalMove(double delta, PhyloBayes* BackUp);
		double				nodeSlidingMove(double delta, PhyloBayes* BackUp);
		double				localMove2(double lambda, PhyloBayes* BackUp);
		double				nodeSlidingMove2(double delta, PhyloBayes* BackUp);

		double				TreeLengthMove(double delta, PhyloBayes* BackUp);
		double				AllBranchMove(double delta, PhyloBayes* BackUp);
		double				OneBranchMove(double delta, PhyloBayes* BackUp);

		double				fastBranchMove(double delta, int N, PhyloBayes* BackUp);
		double				fastBranchRateMove(double delta, int N, PhyloBayes* BackUp);
		double				fastBranchSwitchMove(double delta, int N, PhyloBayes* BackUp);
		double				fastRateMove(double delta, int N, PhyloBayes* BackUp);
		double				fastDirRateMove(double delta, int N, PhyloBayes* BackUp);

		double				dirRateMove(double epsilon, int N, PhyloBayes* BackUp);
		double				RateMove(double epsilon, int N, PhyloBayes* BackUp);
		double				branchRateMove(double epsilon, PhyloBayes* BackUp);
		double				branchSwitchMove(double epsilon, PhyloBayes* BackUp);
		double				switchProbMove(double epsilon, PhyloBayes* BackUp);
		double				RateVarMove(double epsilon, int N, PhyloBayes* BackUp);
		double				dirRateVarMove(double epsilon, int N, PhyloBayes* BackUp);
		double				binaryDirRateMove(double epsilon, int N, PhyloBayes* BackUp);
		double				gammaMove(double delta, PhyloBayes* BackUp);
		double				meanLengthMove(double delta, PhyloBayes* BackUp);
		double				deltaMove(double delta, PhyloBayes* BackUp);
		double				xiMove(double delta, PhyloBayes* BackUp);
		double				pconstMove(double delta, PhyloBayes* BackUp);
		double				invProbMove(double delta, PhyloBayes* BackUp);

		double				refRelRateMove(double delta, int N,  PhyloBayes* BackUp);
		double				refStationaryMove(double epsilon, int N, PhyloBayes* BackUp);
		double				refStatCenterMove(double epsilon, int N, PhyloBayes* BackUp);
		double				refStatAlphaMove(double epsilon, PhyloBayes* BackUp);

		double				modeRelRateMove(double delta, int N,  PhyloBayes* BackUp);
		double				modeStatCenterMove(double epsilon, int N, PhyloBayes* BackUp);
		double				modeStationaryMove(double epsilon, int N, PhyloBayes* BackUp);
		double				modeStationaryMoveEx(double epsilon, int N, PhyloBayes* BackUp);
		double				modeStatAlphaMove(double epsilon, PhyloBayes* BackUp);

		double				RateSwitchModeMove(int N,  PhyloBayes* BackUp);
		double				RateAlphaMove(double delta, PhyloBayes* BackUp);
		double				ModeRateMove(double delta, PhyloBayes* BackUp);
		double				RateSwitchModeMoveEx(int N,  PhyloBayes* BackUp);
		double				ModeRateMoveEx(double delta, PhyloBayes* BackUp);
		double				fastRateSwitchModeMoveEx(int N,  PhyloBayes* BackUp);
		double				fastModeRateMoveEx(double delta, int N,  PhyloBayes* BackUp);
		double				rateGammaMove(double delta, PhyloBayes* BackUp);

		double				RateSwitchModeMoveInt(int N, PhyloBayes* BackUp);

		double				switchModeMove(int N,  PhyloBayes* BackUp);
		double				alphaMove(double delta, PhyloBayes* BackUp);

		double				switchModeIntMove(PhyloBayes* BackUp);
		double				switchModeIntMove2(int N, PhyloBayes* BackUp);
		double				splitMergeIntMove(int N,  PhyloBayes* BackUp);
		double				alphaIntMove(double delta, PhyloBayes* BackUp);

		// helper functions
		void				SwapModes(int mode1, int mode2);
		void				rootAtRandom();
		void				rootAt0();
		void				rootAt(int label);

		void				AddSite(int mode, int site);
		void				RemoveSite(int mode, int site);
		double				DiffLogSampling(int mode, int site);
		double				GibbsScan(int mode1, int mode2, int* indices, int Ns, double& logsamp);
		double				GibbsScanLogRatio(int mode1, int mode2, int* launch, int* target, int* indices, int Ns, int orientation, double& logsamp);


		void				SampleStationaries(int mode);

		void				ResampleStat();
		void				ResampleState();
		void				ResampleRate();
		void				ResamplePoissonState();
		void				ResampleMatrixState();
		void				ResampleZipState();
		void				ResampleSub();
		void				ResampleSubZip();
		void				ResampleSubPoisson();
		void				ResampleSubMatrix();
		void				ResamplePoissonStateThermo();

		double				SiteFastLogSampling(int site);
		double				BranchFastLogSampling(int branch);
		void				UpdateFastLogSampling();

		double				SiteFastLogSamplingZip(int site);
		double				BranchFastLogSamplingZip(int branch);
		double				SiteFastLogSamplingZipBranchRate(int site);
		double				BranchFastLogSamplingZipBranchRate(int branch);
		double				SiteFastLogSamplingMatrix(int site);
		double				BranchFastLogSamplingMatrix(int branch);
		double				SiteFastLogSamplingCovarion(int site);
		double				BranchFastLogSamplingCovarion(int branch);
		double				SiteFastLogSamplingMatrixBranchRate(int site);
		double				BranchFastLogSamplingMatrixBranchRate(int branch);

		double				BranchRateFastLogSampling(int branch, int site);
		double				BranchRateFastLogSamplingZip(int branch, int site);
		double				BranchRateFastLogSamplingMatrix(int branch, int site);

		double				FastLogSamplingPoisson();
		double				SiteFastLogSamplingPoisson(int site);
		double				BranchFastLogSamplingPoisson(int branch);

		void				ReinitialiseBranchLengths();

		double				FastLogSampling();
		double				PushFastLogSamplingHomotache(double* array);
		double				PushFastLogSamplingHeterotache(double* array);
		double				PushFastLogSamplingUniform(double* array);
		double				PushFastLogSamplingRAS(double* array);
		double				FastLogSamplingHomotache();
		double				FastLogSamplingHeterotache();

		//-------------
		// member data fields
		//-------------

		MCParameters*			mParam;

		double 				Beta;
		double				Zeta;

		AmphiNode*			root;
		AmphiNode*			tree;

		AmphiNode*			root2;
		AmphiNode*			tree2;

		double*				rate;
		double*				unirate;
		double				gamma;
		double				pconst;

		// data fields bearing on modes

		double 				alpha;
		int 				NmodeMax;
		int 				Nmode;
		int*				Mode;
		int*				SiteNumber;

		// stationaries and matrices

		double**			RefZipStationary;
		double*				RefStationary;
		double*				RefStatCenter;
		double				RefStatAlpha;
		double*				RefRR;
		SubMatrix*			mSubMatrix;
		double				RefRateFactor;

		double**			Stationary;
		SubMatrix**			mMatrixArray;
		double**			ZipStationary;

		double*				ModeStatCenter;
		double				ModeStatAlpha;
		double*				ModeRR;
		double*				ModeRateFactor;

		double				rateFactor;
		// probability fields
		// when logPrior() / logSampling() / logPosterior() is called, then
		// what is returned is mLogPrior / mLogSampling / mLogPosterior, if  != -1
		// if == -1 :  they are recomputed from scratch

		double 				mLogPrior;
		double				mLogSampling;
		double				mTotalFastLogSampling;
		double				mLogPosterior;
		double				mModeLogSampling;
		double*				mSiteLogSampling;

		double*				mBranchFastLogSampling;
		double*				mSiteFastLogSampling;


		// inits

		InitMode			InitTree;
		InitMode			InitBranchLength;
		double				InitInternalLength;
		double				InitLeafLength;

		InitMode			InitRate;
		InitMode			InitBranchRate;
		InitMode			InitRateVar;
		InitMode			InitGamma;
		InitMode			InitRateGamma;
		InitMode			InitDelta;
		InitMode			InitXi;
		InitMode			InitPconst;

		InitMode			InitRefRR;
		InitMode 			InitRefStat;
		InitMode			InitRefStatCenter;
		InitMode			InitRefStatAlpha;

		InitMode			InitModeRR;
		InitMode			InitModeStat;
		InitMode			InitModeStatCenter;
		InitMode			InitModeStatAlpha;

		InitMode			InitModeAffiliation;
		InitMode			InitAlpha;
		InitMode			InitNmode;
		InitMode			InitRateAlpha;
		InitMode			InitNRateMode;

		Switch				IsInitBranchLength;
		Switch				IsInitTree;
		Switch				IsInitTree2;

		Switch				IsInitRate;
		Switch				IsInitBranchRate;
		Switch				IsInitRateVar;
		Switch				IsInitGamma;
		Switch				IsInitRateGamma;
		Switch				IsInitDelta;
		Switch				IsInitXi;
		Switch				IsInitPconst;

		Switch				IsInitRefRR;
		Switch	 			IsInitRefStat;
		Switch	 			IsInitRefStatCenter;
		Switch	 			IsInitRefStatAlpha;

		Switch				IsInitModeRR;
		Switch	 			IsInitModeStat;
		Switch	 			IsInitModeStatCenter;
		Switch	 			IsInitModeStatAlpha;

		Switch				IsInitModeAffiliation;
		Switch				IsInitAlpha;
		Switch				IsInitNmode;
		Switch				IsInitNRateMode;
		Switch				IsInitRateAlpha;


		// working data structures
		double**			tbl;
		double*				taux;
		double*				taux2;
		double* 			mModeGibbsGrid;
		double* 			mLogSamplingArray;
		double*				EigenVect;
		double*				InvEigenVect;
		double*				EigenVal;

		int				Version;
		int				SubVersion;


		int***				BranchSubSeries;
		void				CreateBranchSubSeries();

		int**				State;			// node  site
		int***				BranchNsub;		// branch site state
		int**				BranchTotalSub;		// branch site
		int**				Nsub;			// site state
		int*				TotalSub;		// site
		int*				ModeGrandTotal;		// mode state
		int**				ModeTotal;		// mode

		int*				RateModeTotal;
		void				UpdateRateModeTotal();
		void				UpdateRateModeTotal(int mode);

		double*				aux;

		double				minrate;
		double 				maxrate;

		double***			PartialLikelihood;
		int				StorePartialLikelihoods;
		
		int**				Data;
		int**				ZipData;

		double*				ratevar;
		double				xi0;
		double				delta;

		double				s01;
		double				s10;
		double*				sites01;
		double*				sites10;

		CovSubMatrix*			mCovSubMatrix;
		CovSubMatrix**			mCovSubMatrixArray;

		double**			branchrate;
		int**				branchswitch;

		double*				siteinvprob;
		double				invprob;			// covarion : prob 0 state


		int				Nswitch;
		int*				siteNswitch;
		int*				branchNswitch;

		int				Non;
		int*				siteNon;

		double*				logarray;

		double				SameProbZ;
		double				SiteProbZ;
		double				BranchProbZ;

		double				MinBranchRate;

		double 				RateAlpha;
		int*				RateMode;
		int				NRateMode;
		double*				ModeRate;
		int*				RateSiteNumber;
		int				NRateModeMax;
		// double*				moderate;

		void				CloneModeRates(PhyloBayes& from);
		void				MakeRates();
		void				UpdateRateModes();
		
		double				logModeRatePrior();
		double				logModeRatePrior(int i);
		double				logRateAlphaPrior();
		void				SwapRateModes(int mode1, int mode2);
		double				GetMeanModeRate();
		double				RateGamma;

		double				TotalLength;
		double				MeanLength;
		double				UpdateTotalLength();

		double				RateModeDiffLogSampling(int mode, int site);
		void				StoreRateGammaLog();
		double*				mRateGammaLog;
		double*				CumulRateFactor;
		void				UpdateCumulRateFactor();
		double*				SiteEffLength;
		double*				RateModeEffLength;
		
		void				SwapTree();
		void				HomogeneiseBranchLengths();
		
		double 				PoissonLogProbSub();	
		double 				PoissonLogProbSub2();	
		double 				PoissonMarginalLogProbSub();	
		
		double 				PoissonLogProbSubUni();	
		double 				PoissonMarginalLogProbSubUni();	
	
		double				DrawAllBranch(double delta, PhyloBayes* from);
		double				AllBranchLogAlpha(double delta, PhyloBayes* from);
		double				AllBranchLogAlphaQ(double delta, PhyloBayes* from);

		double				GetMappingLogProb(); // poisson
		double				logProbStatePruning(const AmphiNode*, int atSite);
		double 				logProbSubPoisson();
		
		double 				cSIS();
		void				ComputeBLGradient(double* gradient, int nrep);
};
	
		


