
class BipartitionList;

class BooleanBipartitionList	{

	public:

	// mise en oeuvre:
	// un tableau de (2*Ntaxa-7) * (Ntaxa-1) booleens
	// les Bipartitions contenues dans une telle liste etant forcement compatibles entre elles
	// il ne peut y en avoir plus de 2*Ntaxa -7

	BooleanBipartitionList(TaxaParameters* inParam);	// make an empty list

	BooleanBipartitionList(  BipartitionList* inBList, double cutoff = 0.);

	~BooleanBipartitionList();


	// member ?
	Boolean 				operator() ( const Bipartition& inPartition);
	Boolean 				operator() ( const Bipartition& inPartition) const;

	Int16					GetSize();
	Bipartition&				operator[]( Int16 index );

	double					GetProb(Int16 index)	{ return mProbArray[index];}
	double					GetLength(Int16 index)	{ return mLengthArray[index];}
	Bipartition& 				GetBipartition(int index)	{return *(mArray[index]);}

	Boolean					Push(Bipartition& , double prob, double length);
												// return true if the Bipartition to be included is compatible with
												// the one elready present in this
	void					FastPush(const Bipartition&, double length);
	void					Pop(); 
	void					PopDuplicate(); 

	Boolean					IsCompatibleWith( const Bipartition& );

	TaxaParameters*				GetParameters()	{return mParam;}

	void					Flush();
	void					ToString(ostream& os);

	void					Modulo();

	TaxaParameters*				mParam;
	Int16 					mSize;
	int					checksize;
	Int16					mCurrentSize;
	Bipartition**				mArray;
	double*					mProbArray;
	double*					mLengthArray;
}
;
