
class MCParameters;
class Bipartition;
class Tree;

class TaxaParameters	{

	public:

	TaxaParameters(int N, string* inNames = 0);
	TaxaParameters(MCParameters* inParam);
	TaxaParameters(string datafile);
	TaxaParameters(ifstream& is);
	TaxaParameters(Tree* inTree);

	TaxaParameters(const TaxaParameters& from);

	~TaxaParameters();

	void ReadFromStream(ifstream& is);

	void Eliminate(Bipartition& toEliminate);
	

	string	GetSpeciesName(Int16 index);

	Boolean Member(Int16 index);

	MCParameters*	GetParameters()	{return mParam;}

	Bipartition			GetOutGroup();
	void				SetOutGroup(Bipartition& inOutGroup);

	int				GetSpeciesNumber()	{return Nspecies;}
	int				GetNodeNumber()	{return 2*Nspecies-1;}

	int				GetFullSpeciesNumber();	
	int				Ntaxa()	const;

	friend ostream&	operator<<(ostream& os , const TaxaParameters& param);
	friend istream& operator>>(istream& is, TaxaParameters& param);

	MCParameters*			mParam;
	Boolean*			mArray;				// 0 : not included
									// 1: included
	Boolean*			mOutGroup;
	int				Nspecies;			// internal number of taxa
	
									// <> from mParam->Ntaxa
	string*				SpeciesNames;
		
}
;
