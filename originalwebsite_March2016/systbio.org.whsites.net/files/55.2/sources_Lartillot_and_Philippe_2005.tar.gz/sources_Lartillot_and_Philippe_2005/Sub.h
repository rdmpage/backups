

class PhyloBayes;

class Sub	{

	public :

			Sub(PhyloBayes* inPB);
			~Sub();

	void		FlushStateGrid();
	void		SubPruning(PolyNode* node, int site);
	int		BPCompatible(int site, BooleanBipartitionList* bplist);
	void		BPCompatible(BooleanBipartitionList* bplist, int* CompArray);


	void		ToLatex(ostream& os, double sizeX, double sizeY, int withLengths, int site = -1);
	double		Draw(PolyNode* node, ostream& os, double scaleX, double scaleY, int site);
	void		ToPaup();
	void		ReadPaup();
	void		WriteStatesToStream(ostream& os);

	friend ostream& operator<<(ostream& os, Sub& sub);
	friend istream& operator>>(istream& is, Sub& sub);
	
	Tree*		mTree;
	TaxaParameters* taxaparam;
	MCParameters*	mParam;

	int**				State;			// node  site
	int***				BranchNsub;		// branch site state
	int**				BranchTotalSub;		// branch site
	int**				Nsub;			// site state
	int*				TotalSub;		// site
	int***				BranchSubSeries;

	int**				StateGrid;	
}
;
