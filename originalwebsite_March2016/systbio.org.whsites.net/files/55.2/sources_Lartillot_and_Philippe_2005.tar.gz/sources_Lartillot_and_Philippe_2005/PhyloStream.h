
#include "myenv.h"
#include "Constants.h"

	otstream& operator<<(otstream& ots, InitMode in);
	otstream& operator<<(otstream& ots, Switch in);
	otstream& operator<<(otstream& ots, Prior in);
	otstream& operator<<(otstream& ots, MoveType in);
	ocstream& operator<<(ocstream& ocs, InitMode in);
	ocstream& operator<<(ocstream& ocs, Switch in);
	ocstream& operator<<(ocstream& ocs, Prior in);
	ocstream& operator<<(ocstream& ocs, HeterotachyMode in);
	ocstream& operator<<(ocstream& ocs, HeterogeneityMode in);
	ocstream& operator<<(ocstream& ocs, MoveType in);
	ocstream& operator<<(ocstream& ocs, TopoMoveType in);
	ocstream& operator<<(ocstream& ocs, ModelSwitchMode in);
	ocstream& operator<<(ocstream& ocs, MCMCMCType in);


	icstream& operator>>(icstream& ics, InitMode& in);
	icstream& operator>>(icstream& ics, Switch& in);
	icstream& operator>>(icstream& ics, Prior& in);
	icstream& operator>>(icstream& ics, HeterotachyMode& in);
	icstream& operator>>(icstream& ics, HeterogeneityMode& in);
	icstream& operator>>(icstream& ics, MoveType& in);
	icstream& operator>>(icstream& ics, TopoMoveType& in);
	icstream& operator>>(icstream& ics, ModelSwitchMode& in);
	icstream& operator>>(icstream& ics, MCMCMCType& in);


InitMode ReadMode(string s);
